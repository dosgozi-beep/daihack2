# ダイハック V2 — プロジェクト構成

## ファイル構成（A-2 軽い分割）

```
daihack-v2/
├── index.html              ← マークアップ本体
├── style.css               ← スタイル全体
├── script.js               ← ロジック・データ操作・ローカルストレージ
├── manifest.json           ← PWA設定
├── service-worker.js       ← オフラインキャッシュ
│
├── data/
│   ├── models.json         ← モデル（個人ジャーニー）データ
│   ├── orgs.json           ← 団体データ
│   └── keitou.json         ← 5系統の定義
│
└── assets/
    ├── icon-192.png        ← PWAアイコン小
    ├── icon-512.png        ← PWAアイコン大
    ├── icon.svg            ← ソースSVG
    │
    ├── characters/         ← リソグラフ風キャラ画像
    │   ├── shosha.png      （赤スーツ・世界地図背景）
    │   ├── startup.png     （黄色背景・パーカー）
    │   ├── scholar.png     （丸メガネ・本棚）
    │   ├── creator.png     （デニムサロペット・絵の具）
    │   └── global.png      （赤マフラー・飛行機）
    │
    └── models/             ← 個人モデルのアバター画像（任意）
        └── （申請者がアップロードする想定）
```

## デザイントークン（CSS変数）

旧版から継承、リブランディング後も維持：

```css
--bg: #f1e8d3       /* 和紙クリーム背景 */
--paper: #fbf6e9    /* 紙 */
--ink: #161616      /* 墨 */
--vermilion: #d63a2f /* 朱赤 */
--yellow: #ffd60a   /* 蛍光イエロー */
--blue: #1d3557     /* 紺 */
--sage: #6f8a5e     /* セージグリーン */
```

## フォント

**M PLUS Rounded 1c** 一本（weight 500/700/800/900）。
画面全体の質量を均一にする戦略。

## データ永続化（B-2）

- ユーザーの計画ページ・remix 履歴 → `localStorage`
- 公開モデルデータ → `data/models.json`（静的、git管理）
- 申請 → JSON ダウンロード → 運営に送付 → 運営が models.json に追記

## 系統 ID と キャラ画像の対応

| ID | 名前 | アイコン色 | キャラ画像 |
|---|---|---|---|
| shosha | 商社マン/グローバル大手 | #d63a2f 朱赤 | shosha.png |
| startup | 起業家/スタートアップ | #ffd60a 黄 | startup.png |
| scholar | 研究者/大学院 | #1d3557 紺 | scholar.png |
| creator | クリエイター/表現者 | #6f8a5e 緑 | creator.png |
| global | グローバル/国際派 | #161616 黒 | global.png |
