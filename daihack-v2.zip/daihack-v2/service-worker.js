// daihack v2 service worker
// 戦略: install で静的アセットをキャッシュ。fetch は cache-first（静的）/ network-first（データ）

const VERSION = 'daihack-v2-0.2.0';
const STATIC_CACHE = `${VERSION}-static`;
const DATA_CACHE = `${VERSION}-data`;

// 起動時にキャッシュする静的アセット（最小コア。画像は fetch 時に随時キャッシュ）
const STATIC_ASSETS = [
  './',
  './index.html',
  './style.css',
  './script.js',
  './manifest.json',
  './assets/icon.svg',
  './assets/icon-192.png',
  './assets/icon-512.png',
  // Google Fonts はキャッシュしない（外部CDN、別ドメイン）
  // キャラ画像・団体ロゴは fetch ハンドラの cache-first で自動的にキャッシュされる
];

// データファイル（network-first にしたいもの）
const DATA_PATHS = [
  './data/models.json',
  './data/orgs.json',
  './data/keitou.json',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) =>
      // 個別に追加し、1つの失敗で全体が落ちないようにする
      Promise.all(STATIC_ASSETS.map((url) =>
        cache.add(url).catch((e) => console.warn('SW cache skip:', url, e))
      ))
    )
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((k) => !k.startsWith(VERSION))
          .map((k) => caches.delete(k))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // 同じオリジン外（Google Fonts等）は素通し
  if (url.origin !== self.location.origin) return;

  const path = url.pathname;
  const isData = DATA_PATHS.some((p) => path.endsWith(p.replace('./', '/')));

  if (isData) {
    // データは network-first（最新を取りに行く、失敗したらキャッシュ）
    event.respondWith(
      fetch(event.request)
        .then((res) => {
          const clone = res.clone();
          caches.open(DATA_CACHE).then((cache) => cache.put(event.request, clone));
          return res;
        })
        .catch(() => caches.match(event.request))
    );
  } else {
    // 静的は cache-first（取得成功した同一オリジンGETは随時キャッシュ）
    event.respondWith(
      caches.match(event.request).then((cached) => {
        if (cached) return cached;
        return fetch(event.request).then((res) => {
          if (event.request.method === 'GET' && res.ok && res.type === 'basic') {
            const clone = res.clone();
            caches.open(STATIC_CACHE).then((cache) => cache.put(event.request, clone));
          }
          return res;
        });
      })
    );
  }
});
