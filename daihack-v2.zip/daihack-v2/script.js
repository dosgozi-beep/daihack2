/* ============================================================
   ダイハック V2 — script.js
   構成:
   1. 定数・グローバル状態
   2. データ層
      - 静的データ読み込み (keitou/models/orgs)
      - ローカルストレージ (ユーザーの計画ページ)
   3. ヘルパー
      - HTML エスケープ・テンプレート
      - 日付・stage 変換
      - アバター生成
      - トースト
   4. ルーター（ハッシュベース）
   5. 画面レンダラーディスパッチ
   6. 個別画面レンダラー（最初は plain placeholder）
   7. グローバルイベントハンドラ
   8. PWA Service Worker 登録
   9. 起動
   ============================================================ */

'use strict';

/* ============================================================
   1. 定数・グローバル状態
   ============================================================ */
const APP_VERSION = '0.1.0';
const STORAGE_KEY = 'daihack-v2-user-plan';

// 全データのインメモリストア。起動時にロードして保持。
const Store = {
  keitou: [],        // [{ id, label_ja, color, character_image, ... }]
  models: [],        // [{ id, handle, display_name, cards: [...], ... }]
  orgs: [],          // [{ id, name, ... }]
  userPlan: null,    // ローカルストレージから復元したユーザーの計画
};

/* stage ID → 表示名 マッピング */
const STAGE_LABEL = {
  shougakkou: '小学',
  chuugakkou: '中学',
  kokou_1: '高1', kokou_2: '高2', kokou_3: '高3',
  daigaku_1_zenki: '大1 前期', daigaku_1_kouki: '大1 後期', daigaku_1_tsunen: '大1 通年',
  daigaku_2_zenki: '大2 前期', daigaku_2_kouki: '大2 後期', daigaku_2_tsunen: '大2 通年',
  daigaku_3_zenki: '大3 前期', daigaku_3_kouki: '大3 後期', daigaku_3_tsunen: '大3 通年',
  daigaku_4_zenki: '大4 前期', daigaku_4_kouki: '大4 後期', daigaku_4_tsunen: '大4 通年',
  shakaijin: '社会人',
};

/* 学年単位（calling: stage → era）への正規化 */
const STAGE_TO_ERA = {
  shougakkou: 'pre',
  chuugakkou: 'pre',
  kokou_1: 'kokou', kokou_2: 'kokou', kokou_3: 'kokou',
  daigaku_1_zenki: 'daigaku_1', daigaku_1_kouki: 'daigaku_1', daigaku_1_tsunen: 'daigaku_1',
  daigaku_2_zenki: 'daigaku_2', daigaku_2_kouki: 'daigaku_2', daigaku_2_tsunen: 'daigaku_2',
  daigaku_3_zenki: 'daigaku_3', daigaku_3_kouki: 'daigaku_3', daigaku_3_tsunen: 'daigaku_3',
  daigaku_4_zenki: 'daigaku_4', daigaku_4_kouki: 'daigaku_4', daigaku_4_tsunen: 'daigaku_4',
  shakaijin: 'shakaijin',
};

const ERA_LABEL = {
  pre: '高校以前',
  kokou: '高校時代',
  daigaku_1: '大学1年',
  daigaku_2: '大学2年',
  daigaku_3: '大学3年',
  daigaku_4: '大学4年',
  shakaijin: '社会人',
};

const ERA_ORDER = ['pre', 'kokou', 'daigaku_1', 'daigaku_2', 'daigaku_3', 'daigaku_4', 'shakaijin'];

/* カテゴリ表示 */
const CATEGORY_LABEL = {
  academic: '学業',
  career: 'キャリア',
  network: '人脈',
  skill: 'スキル',
  global: '海外',
};

/* コラボ種別 */
const COLLAB_LABEL = {
  interview: '取材',
  mentoring: 'メンタリング',
  talk: '登壇',
  recruit: '採用相談',
};

/* ============================================================
   2. データ層
   ============================================================ */

async function loadStaticData() {
  const [keitou, models, orgs] = await Promise.all([
    fetch('./data/keitou.json').then(r => r.json()),
    fetch('./data/models.json').then(r => r.json()),
    fetch('./data/orgs.json').then(r => r.json()),
  ]);
  Store.keitou = keitou.keitou;
  Store.models = models.models;
  Store.orgs = orgs.orgs;
  // 申請スキーマ（任意：読めなくてもアプリは動く。読めれば申請JSONを書き出し前に検証）
  try {
    Store.applicationSchema = await fetch('./data/application-schema.json').then(r => r.ok ? r.json() : null);
  } catch (e) {
    Store.applicationSchema = null;
  }
}

function loadUserPlan() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      Store.userPlan = JSON.parse(raw);
    } else {
      Store.userPlan = createEmptyPlan();
    }
  } catch (e) {
    console.warn('Failed to load user plan from localStorage:', e);
    Store.userPlan = createEmptyPlan();
  }
}

function saveUserPlan() {
  try {
    Store.userPlan.updated_at = new Date().toISOString();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(Store.userPlan));
    return true;
  } catch (e) {
    console.error('Failed to save user plan:', e);
    showToast('保存に失敗しました', 'warn');
    return false;
  }
}

function createEmptyPlan() {
  return {
    schema_version: 1,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    profile: {
      display_name: '',
      handle: '',
      campus: '',
      current_year: 'daigaku_1',
    },
    cards: [],
    liked_card_ids: [],
    intentional_overlaps: [],  // 「このまま重ねる」を選んだ重なりの記録
  };
}

/* カード操作 */
function addCardToPlan(card) {
  if (!card.id) {
    card.id = `usercard_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  }
  card.created_at = new Date().toISOString();
  Store.userPlan.cards.push(card);
  saveUserPlan();
  return card.id;
}

function updateCardInPlan(cardId, updates) {
  const idx = Store.userPlan.cards.findIndex(c => c.id === cardId);
  if (idx === -1) return false;
  Store.userPlan.cards[idx] = { ...Store.userPlan.cards[idx], ...updates };
  saveUserPlan();
  return true;
}

function removeCardFromPlan(cardId) {
  Store.userPlan.cards = Store.userPlan.cards.filter(c => c.id !== cardId);
  saveUserPlan();
}

/* ============================================================
   3. ヘルパー
   ============================================================ */

/** HTML エスケープ */
function esc(s) {
  if (s == null) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/** タグ付きテンプレートリテラル: html`<div>${ unsafe }</div>` */
function html(strings, ...values) {
  return strings.reduce((out, str, i) => {
    let v = values[i - 1];
    if (Array.isArray(v)) v = v.join('');
    return out + (i > 0 ? (v == null ? '' : v) : '') + str;
  });
}

/** stage ID から見やすいラベル */
function stageLabel(stage) {
  return STAGE_LABEL[stage] || stage;
}

/** 系統オブジェクトを取得 */
function getKeitou(id) {
  return Store.keitou.find(k => k.id === id);
}

/** モデルを取得 */
function getModel(id) {
  return Store.models.find(m => m.id === id);
}

/** モデルをハンドル名で取得 */
function getModelByHandle(handle) {
  return Store.models.find(m => m.handle === handle);
}

/** 団体を取得 */
function getOrg(id) {
  return Store.orgs.find(o => o.id === id);
}

/** モデル詳細URL */
function modelUrl(modelId) {
  return `#/model/${modelId}`;
}
function orgUrl(orgId) {
  return `#/org/${orgId}`;
}

/** アバターHTML生成
 *  個人モデルのアバターは「系統キャラ画像 ＋ 頭文字」の合成 */
/** 団体エンブレム（ロゴSVGがあれば画像、なければ文字） */
function renderOrgEmblem(org, sizeClass) {
  if (org.logo) {
    return `<div class="emblem ${sizeClass} emblem-img"><img src="${esc(org.logo)}" alt="${esc(org.name)}" loading="lazy"></div>`;
  }
  const l1 = esc(org.emblem_text_line1 || '');
  const l2 = org.emblem_text_line2 ? '<br>' + esc(org.emblem_text_line2) : '';
  return `<div class="emblem ${sizeClass}">${l1}${l2}</div>`;
}

function renderAvatar(model, size = 'md') {
  // モデル自身のキャラ画像があれば顔クロップの円形アイコンに（MAPと同じ見た目）
  const img = model.character_image;
  if (img) {
    const imgUrl = img.startsWith('data:') ? img : img.replace(/\.png$/, '.webp');
    const face = (typeof MAP_PLACEMENT !== 'undefined' && MAP_PLACEMENT[model.id]?.face)
      || { px: 50, py: 18, zoom: 235 };
    const design = getModelDesign(model);
    return html`
      <div class="avatar avatar-${size} avatar-face"
           style="--icon-ring:${design.personalColor}; background-image:url('${imgUrl}'); background-size:${face.zoom}%; background-position:${face.px}% ${face.py}%;"></div>
    `;
  }
  // フォールバック：系統イメージ＋文字アバター
  const keitouId = model.avatar_keitou || model.keitou?.[0] || 'creator';
  const keitou = getKeitou(keitouId);
  const charImg = keitou ? keitou.character_image : null;
  const seed = model.avatar_seed || model.display_name?.[0] || '?';
  const bgStyle = charImg ? `style="background-image:url('${esc(charImg)}')"` : '';
  return html`
    <div class="avatar avatar-${size} avatar--${esc(keitouId)}">
      ${charImg ? html`<div class="avatar-bg" ${bgStyle}></div>` : ''}
      <span class="avatar-letter">${esc(seed)}</span>
    </div>
  `;
}

/** キャラ画像を <picture> でレンダリング（WebP優先、PNG fallback） */
function renderCharacterImage(imagePath) {
  if (!imagePath) return '';
  // base64 data URI（プレビュー版）はそのまま img タグ
  if (imagePath.startsWith('data:')) {
    return html`<img src="${esc(imagePath)}" alt="" loading="lazy">`;
  }
  // 通常のパス（assets/characters/handle.png）→ .webp 版を優先
  const webpPath = imagePath.replace(/\.png$/, '.webp');
  return html`
    <picture>
      <source srcset="${esc(webpPath)}" type="image/webp">
      <img src="${esc(imagePath)}" alt="" loading="lazy">
    </picture>
  `;
}

/** 系統名タグ */
function renderKeitouTags(keitouIds) {
  return keitouIds.map(id => {
    const k = getKeitou(id);
    if (!k) return '';
    return html`<span class="pill pill-sage-pale">${esc(k.label_en)}</span>`;
  }).join('');
}

/** ステータスピル */
function renderStatusPill(status, compact = false) {
  const cls = compact ? 'status-pill' : 'pill';
  if (status === 'shinkochu') {
    return compact
      ? html`<span class="status-pill status-pill-shinkochu">● SHINKOCHU</span>`
      : html`<span class="pill pill-shinkochu">SHINKOCHU / 進行中</span>`;
  } else if (status === 'sotsugyo') {
    return compact
      ? html`<span class="status-pill status-pill-sotsugyo">● SOTSUGYO</span>`
      : html`<span class="pill pill-sotsugyo">SOTSUGYO / 卒業</span>`;
  }
  return '';
}

/** トースト表示 */
function showToast(text, variant = '') {
  const area = document.getElementById('toast-area');
  const div = document.createElement('div');
  div.className = `toast ${variant ? `toast-${variant}` : ''}`;
  div.textContent = text;
  area.appendChild(div);
  setTimeout(() => {
    div.style.transition = 'opacity 0.3s';
    div.style.opacity = '0';
    setTimeout(() => div.remove(), 300);
  }, 2200);
}

/** 4条件レディネス判定（論点G-2で確定）
 *  ユーザーの計画ページが、モデル申請の条件をどれだけ満たしているかを返す。
 *  - A: 時間的カバー（2つ以上の異なる学期にカード）
 *  - B: 個別カードの完成度（ふりかえり済みカードすべてに why と reflection）
 *  - C: 自分の言葉（remix カードのうち、半分以上で why が元と違う）
 *  - D: オリジナルカード1枚以上（parent が null のカード）
 */
function checkReadiness() {
  const plan = Store.userPlan;
  const cards = plan?.cards || [];
  const reflected = cards.filter(c => c.state === 'reflected');

  // 0枚の場合はすべて false
  if (cards.length === 0) {
    return {
      conditions: {
        spans_multiple_terms: false,
        all_cards_have_why: false,
        majority_remixed_why: false,
        has_original_card: false,
      },
      conditions_met: 0,
      total_conditions: 4,
      all_met: false,
      next_actions: ['まずは先輩のカードを保存するか、自分のカードを書いてみよう'],
    };
  }

  // A: 時間カバー（reflected カードが2つ以上の異なる学期に存在）
  const stages = new Set(reflected.map(c => c.when?.stage).filter(Boolean));
  const spansMultipleTerms = stages.size >= 2;

  // B: ふりかえり済みカードすべてに why と reflection が存在
  const allCardsHaveWhy = reflected.length > 0 && reflected.every(c =>
    c.why && c.why.trim().length > 0 &&
    c.result?.reflection && c.result.reflection.trim().length > 0
  );

  // C: remix カードのうち、why を自分の言葉で書いた割合が半分以上
  const remixedCards = cards.filter(c => c.parent);
  let majorityRemixedWhy;
  if (remixedCards.length === 0) {
    // remix が0なら、判定対象なし → このカテゴリは未達成扱い
    // （remix していない＝先輩から学んでいない可能性）
    // ただし、オリジナルだけで成立する場合もあるので、論理的には true でもよいが、
    // 「先輩から学んで」というタグラインの趣旨に従って、最低1つは remix を期待する
    majorityRemixedWhy = false;
  } else {
    const selfWritten = remixedCards.filter(c => {
      if (!c.parent_original_why) return true;
      return c.why?.trim() !== c.parent_original_why.trim();
    });
    majorityRemixedWhy = selfWritten.length >= Math.ceil(remixedCards.length / 2);
  }

  // D: parent が null のオリジナルカードが1枚以上
  const hasOriginalCard = cards.some(c => !c.parent);

  const allMet = spansMultipleTerms && allCardsHaveWhy && majorityRemixedWhy && hasOriginalCard;
  const conditionsMet = [spansMultipleTerms, allCardsHaveWhy, majorityRemixedWhy, hasOriginalCard]
    .filter(Boolean).length;

  return {
    conditions: {
      spans_multiple_terms: spansMultipleTerms,
      all_cards_have_why: allCardsHaveWhy,
      majority_remixed_why: majorityRemixedWhy,
      has_original_card: hasOriginalCard,
    },
    conditions_met: conditionsMet,
    total_conditions: 4,
    all_met: allMet,
    next_actions: getNextActions({
      spansMultipleTerms, allCardsHaveWhy, majorityRemixedWhy, hasOriginalCard,
      cardCount: cards.length,
      reflectedCount: reflected.length,
      remixedCount: remixedCards.length,
    }),
  };
}

/** 「次にやること」のテキストを生成（4条件のうち、満たしていないものを質的に伝える） */
function getNextActions(state) {
  const actions = [];
  if (state.cardCount === 0) {
    return ['まずは先輩のカードを保存するか、自分のカードを書いてみよう'];
  }
  if (!state.hasOriginalCard) {
    actions.push('自分のオリジナルカードを1枚');
  }
  if (!state.spansMultipleTerms) {
    actions.push('ふりかえり済みを別の学期にも');
  }
  if (!state.allCardsHaveWhy) {
    actions.push('カードのふりかえりを埋める');
  }
  if (!state.majorityRemixedWhy) {
    actions.push('remix の why を自分の言葉で');
  }
  return actions;
}

/* ============================================================
   4. ルーター（ハッシュベース）
   ============================================================ */

/** ルートを定義: 各エントリは { match: regex, screen: id, render: function } */
const ROUTES = [
  { match: /^#\/?$/, screen: 'home', render: renderHome },
  { match: /^#\/home$/, screen: 'home', render: renderHome },
  { match: /^#\/search(\?.*)?$/, screen: 'search', render: renderSearch },
  { match: /^#\/plan$/, screen: 'plan', render: renderPlan },
  { match: /^#\/orgs$/, screen: 'orgs', render: renderOrgs },
  { match: /^#\/model\/(.+)$/, screen: 'model', render: renderModel },
  { match: /^#\/org\/(.+)$/, screen: 'org', render: renderOrg },
  { match: /^#\/create(?:\?(.*))?$/, screen: 'remix', render: renderCreateCard },
  { match: /^#\/remix\/(.+)\/(.+)$/, screen: 'remix', render: renderRemix },
  { match: /^#\/apply$/, screen: 'apply', render: renderApply },
  { match: /^#\/settings$/, screen: 'settings', render: renderSettings },
];

/** モデル詳細をどのタブ配下として表示するか（直前にいたメインタブを記憶） */
let __lastMainTab = 'home';

/** どのタブをアクティブにするか */
const SCREEN_TO_TAB = {
  home: 'home',
  search: 'search',
  model: 'search',     // モデル詳細は「探す」配下扱い
  plan: 'plan',
  apply: 'plan',       // 申請は「計画」配下扱い
  settings: 'plan',
  orgs: 'orgs',
  org: 'orgs',
  remix: null,         // モーダルはタブを変えない
};

function getCurrentRoute() {
  const hash = location.hash || '#/home';
  for (const route of ROUTES) {
    const m = hash.match(route.match);
    if (m) return { route, params: m.slice(1) };
  }
  return { route: ROUTES[0], params: [] };
}

function navigateTo(hashPath) {
  if (location.hash === hashPath) {
    handleRouteChange();
  } else {
    location.hash = hashPath;
  }
}

function goBack() {
  if (history.length > 1) {
    history.back();
  } else {
    navigateTo('#/home');
  }
}

function handleRouteChange() {
  const { route, params } = getCurrentRoute();

  // モーダル系（remix）は他の画面を残したまま重ねる
  const isModal = route.screen === 'remix';

  // すべての画面を hidden に（モーダルは除く）
  document.querySelectorAll('.screen').forEach(el => {
    if (isModal && el.dataset.screen !== 'remix') {
      // モーダル表示中は背景画面を残す
      return;
    }
    el.hidden = el.dataset.screen !== route.screen;
  });

  // タブのアクティブ状態
  // モデル詳細は「直前にいたタブ」の配下として表示する（ホームから開いたらホームのまま）
  let activeTab = SCREEN_TO_TAB[route.screen];
  if (route.screen === 'model') {
    activeTab = __lastMainTab || 'search';
  }
  if (['home', 'search', 'plan', 'orgs'].includes(route.screen)) {
    __lastMainTab = SCREEN_TO_TAB[route.screen];
  }
  document.querySelectorAll('.tab').forEach(t => {
    if (activeTab && t.dataset.tab === activeTab) {
      t.setAttribute('aria-current', 'page');
    } else {
      t.removeAttribute('aria-current');
    }
  });

  // レンダリング実行
  try {
    route.render(...params);
  } catch (e) {
    console.error('Render error for', route.screen, e);
    showToast('画面の表示でエラーが発生しました', 'warn');
  }

  // モーダル以外の場合、スクロール位置をリセット
  if (!isModal) {
    window.scrollTo(0, 0);
  }
}

/* ============================================================
   5. 画面レンダラー（プレースホルダー版）
   個別画面は次のステップで肉付けする。いまは存在確認のための
   最小実装。基盤層が動いていることを示すための表示。
   ============================================================ */

function renderHome() {
  const body = document.getElementById('home-body');
  body.innerHTML = renderHomeContent();
  startHeroCarousel();
}

/** ホーム画面の中身を組み立てる（Netflix風レイアウト） */
function renderHomeContent() {
  return [
    renderHomeTopBar(),
    renderHomeHero(),
    renderHomeRecentRow(),
    renderHomeReadinessRow(),
    renderHomeShelves(),
    renderHomeOrgPromo(),
  ].join('');
}

/** トップバー：縮小ロゴ＋タグライン */
function renderHomeTopBar() {
  return html`
    <div class="home-topbar">
      <div class="home-topbar-logo">
        <span class="home-topbar-text">ダイハック</span>
        <span class="home-topbar-symbol" aria-label="先輩から自分、自分から後輩へ">
          <span class="home-node home-node-1"></span>
          <span class="home-arrow"></span>
          <span class="home-node home-node-2"></span>
          <span class="home-arrow"></span>
          <span class="home-node home-node-3"></span>
        </span>
      </div>
      <div class="home-topbar-tagline">
        <span class="home-tag-emp">先輩</span>から学んで、<span class="home-tag-emp">後輩</span>に渡す
      </div>
    </div>
  `;
}

/** ヒーローカード：大型のタイポデザイン */
/** 特集スライドに載せるモデル（カード数順に最大5人） */
function pickFeaturedModels(n = 5) {
  return [...Store.models]
    .filter(m => m.character_image && m.thumb_design)
    .sort((a, b) => {
      const refA = (a.cards || []).filter(c => c.state === 'reflected').length;
      const refB = (b.cards || []).filter(c => c.state === 'reflected').length;
      if (refA !== refB) return refB - refA;
      return (b.cards || []).length - (a.cards || []).length;
    })
    .slice(0, n);
}

/** ヒーローカルーセル（自動スライド＋スワイプ） */
function renderHomeHero() {
  const featured = pickFeaturedModels(5);
  if (featured.length === 0) return '';
  if (featured.length === 1) return renderHeroSlide(featured[0]);

  return html`
    <div class="hero-carousel" id="hero-carousel">
      <div class="hero-carousel-track" id="hero-carousel-track">
        ${featured.map(m => html`<div class="hero-slide">${renderHeroSlide(m)}</div>`).join('')}
      </div>
      <div class="hero-carousel-dots" id="hero-carousel-dots">
        ${featured.map((m, i) => html`
          <button class="hero-dot ${i === 0 ? 'hero-dot-on' : ''}" data-dot="${i}"
                  onclick="heroCarouselGo(${i})" aria-label="${esc(m.display_name)}"></button>
        `).join('')}
      </div>
    </div>
  `;
}

/** ヒーロー1枚分 */
function renderHeroSlide(featured) {
  const design = getModelDesign(featured);
  const catchphrase = featured.thumb_catchphrase || (featured.subtitle || '').slice(0, 10);
  const lines = catchphrase.split('\n');
  const keitouLabel = (featured.keitou || []).map(k => getKeitou(k)?.label_en).filter(Boolean).join(' × ');
  const reflected = (featured.cards || []).filter(c => c.state === 'reflected').length;

  const reflectedCards = (featured.cards || []).filter(c => c.state === 'reflected' && c.why);
  const quote = reflectedCards[Math.floor(Math.random() * reflectedCards.length)];

  return html`
    <a class="home-hero home-hero-${design.pattern} ${isLightColor(design.personalColor) ? 'home-hero--light' : ''}" href="${modelUrl(featured.id)}"
       style="--personal-color:${design.personalColor}; --accent-color:${design.accentColor};">
      <div class="home-hero-base"></div>
      <div class="hero-pattern-layer">${renderThumbPattern(design.pattern)}</div>
      ${featured.character_image ? html`<div class="hero-character">${renderCharacterImage(featured.character_image)}</div>` : ''}
      <div class="hero-top-stamp">
        <span class="hero-stamp-tag">特集 / 今週の先輩</span>
        ${renderStatusPill(featured.status)}
      </div>
      <div class="hero-headline">
        ${lines.map(line => html`<div class="hero-headline-line">${esc(line)}</div>`).join('')}
      </div>
      <div class="hero-footer">
        <div class="hero-footer-handle">${esc(featured.handle.toUpperCase())}</div>
        <div class="hero-footer-name">${esc(featured.display_name)}</div>
        <div class="hero-footer-subtitle">${esc(featured.subtitle)}</div>
        ${quote ? html`
          <div class="hero-footer-quote">"${esc(truncate(quote.why, 60))}"</div>
        ` : ''}
        <div class="hero-footer-meta">
          <span>${esc(keitouLabel)}</span>
          <span class="hero-footer-sep">／</span>
          <span>${(featured.cards || []).length} CARDS</span>
          ${reflected > 0 ? html`<span class="hero-footer-sep">／</span><span>${reflected} ふりかえり済み</span>` : ''}
        </div>
      </div>
    </a>
  `;
}

/* --- カルーセル制御（自動5秒送り・スワイプ・ドット） --- */
let __heroTimer = null;
let __heroIndex = 0;

function heroSlideCount() {
  const track = document.getElementById('hero-carousel-track');
  return track ? track.children.length : 0;
}

function heroCarouselApply() {
  const track = document.getElementById('hero-carousel-track');
  if (!track) return;
  track.style.transform = `translateX(-${__heroIndex * 100}%)`;
  document.querySelectorAll('#hero-carousel-dots .hero-dot').forEach((d, i) => {
    d.classList.toggle('hero-dot-on', i === __heroIndex);
  });
}

window.heroCarouselGo = function(i) {
  const n = heroSlideCount();
  if (n === 0) return;
  __heroIndex = ((i % n) + n) % n;
  heroCarouselApply();
  restartHeroTimer();
};

function restartHeroTimer() {
  clearInterval(__heroTimer);
  __heroTimer = setInterval(() => {
    if (!document.getElementById('hero-carousel-track')) {
      clearInterval(__heroTimer);
      return;
    }
    __heroIndex = (__heroIndex + 1) % heroSlideCount();
    heroCarouselApply();
  }, 5000);
}

function startHeroCarousel() {
  const carousel = document.getElementById('hero-carousel');
  if (!carousel) return;
  __heroIndex = 0;
  heroCarouselApply();
  restartHeroTimer();

  // スワイプ（タッチ中は自動送りを止める）
  let startX = null;
  carousel.addEventListener('touchstart', (e) => {
    startX = e.touches[0].clientX;
    clearInterval(__heroTimer);
  }, { passive: true });
  carousel.addEventListener('touchend', (e) => {
    if (startX == null) return;
    const dx = e.changedTouches[0].clientX - startX;
    startX = null;
    if (dx < -40) heroCarouselGo(__heroIndex + 1);
    else if (dx > 40) heroCarouselGo(__heroIndex - 1);
    else restartHeroTimer();
  }, { passive: true });
}

/** コンパクト READINESS 行 */
function renderHomeReadinessRow() {
  const r = checkReadiness();
  const cards = Store.userPlan.cards || [];

  if (cards.length === 0) {
    return html`
      <a class="home-readiness-mini home-readiness-mini-empty" href="#/plan">
        <span class="home-readiness-mini-icon">+</span>
        <div class="home-readiness-mini-text">
          <div class="home-readiness-mini-title">まだ計画は空っぽ</div>
          <div class="home-readiness-mini-sub">先輩のカードを保存するところから</div>
        </div>
        <span class="home-readiness-mini-arrow">▸</span>
      </a>
    `;
  }

  const allMet = r.all_met;
  return html`
    <a class="home-readiness-mini ${allMet ? 'home-readiness-mini-ready' : ''}" href="#/plan">
      <div class="home-readiness-mini-dots">
        ${[0,1,2,3].map(i => html`<span class="home-readiness-dot ${i < r.conditions_met ? 'home-readiness-dot-on' : ''}"></span>`).join('')}
      </div>
      <div class="home-readiness-mini-text">
        <div class="home-readiness-mini-title">${allMet ? '公開できる状態です' : `あと${r.total_conditions - r.conditions_met}つで公開できる`}</div>
        <div class="home-readiness-mini-sub">あなたの計画 ・ ${cards.length}カード</div>
      </div>
      <span class="home-readiness-mini-arrow">▸</span>
    </a>
  `;
}

/** 複数の横スクロール行（"棚"） */
/* ============================================================
   今週のUP（週替わり更新演出） ＆ 最近見た先輩
   ============================================================ */

/** 今週UPする進行中モデル（週番号で決まる安定ローテーション、3人） */
function getWeeklyUpIds() {
  const week = Math.floor(Date.now() / (7 * 86400000));
  const pool = Store.models.filter(m => m.status === 'shinkochu');
  if (pool.length === 0) return new Set();
  const picked = new Set();
  for (let i = 0; picked.size < Math.min(3, pool.length); i++) {
    picked.add(pool[(week * 7 + i * 5) % pool.length].id);
  }
  return picked;
}

function isUpThisWeek(modelId) {
  if (!window.__weeklyUp) window.__weeklyUp = getWeeklyUpIds();
  return window.__weeklyUp.has(modelId);
}

/** 閲覧履歴の記録（最新が先頭、最大10件） */
function recordRecentModel(modelId) {
  if (!Store.userPlan.recent_models) Store.userPlan.recent_models = [];
  const list = Store.userPlan.recent_models.filter(r => r.id !== modelId);
  list.unshift({ id: modelId, at: new Date().toISOString() });
  Store.userPlan.recent_models = list.slice(0, 10);
  saveUserPlan();
}

/** ホーム：最近見た先輩の行 */
function renderHomeRecentRow() {
  const recents = (Store.userPlan.recent_models || [])
    .map(r => getModel(r.id))
    .filter(Boolean)
    .slice(0, 10);
  if (recents.length === 0) return '';

  return html`
    <div class="recent-row-wrap">
      <div class="recent-row-head">
        <span class="recent-row-title">最近見た先輩</span>
        <span class="recent-row-en">HISTORY</span>
      </div>
      <div class="recent-row no-scrollbar">
        ${recents.map(m => html`
          <a class="recent-item" href="${modelUrl(m.id)}">
            <span class="recent-item-avatar">${renderAvatar(m, 'md')}</span>
            ${isUpThisWeek(m.id) ? html`<span class="recent-up">UP</span>` : ''}
            <span class="recent-item-name">${esc(m.display_name)}</span>
          </a>
        `).join('')}
      </div>
    </div>
  `;
}

function renderHomeShelves() {
  const featured = pickFeaturedModels(5).map(m => m.id);
  const seen = new Set(featured);

  // ステータス棚はヒーロー出演者を除いてピックアップ
  const takeUnseen = (filterFn, limit = 10) => {
    const picked = Store.models.filter(m => !seen.has(m.id) && filterFn(m)).slice(0, limit);
    picked.forEach(m => seen.add(m.id));
    return picked;
  };

  // 棚1: 進行中（reflectedあるもの優先）
  const shelf1 = takeUnseen(m => m.status === 'shinkochu' && (m.cards || []).some(c => c.state === 'reflected'));

  // 棚2: 卒業生
  const shelf2 = Store.models.filter(m => m.status === 'sotsugyo');

  // 系統棚はNetflix式に重複出演OK（その系統の全員を見せる）
  const byKeitou = (...keys) => Store.models.filter(m => (m.keitou || []).some(k => keys.includes(k)));
  const shelfCreator = byKeitou('creator');
  const shelfShoshaGlobal = byKeitou('shosha', 'global');
  const shelfStartup = byKeitou('startup');
  const shelfScholar = byKeitou('scholar');

  const upModels = Store.models.filter(m => isUpThisWeek(m.id));

  return [
    renderShelf({
      title: '今週の更新',
      enTitle: 'UP',
      tag: 'UP!',
      tagColor: 'yellow',
      models: upModels,
    }),
    renderShelf({
      title: '進行中',
      enTitle: 'SHINKOCHU',
      tag: '★ 進行中',
      tagColor: 'vermilion',
      models: shelf1,
    }),
    renderShelf({
      title: '卒業生から学ぶ',
      enTitle: 'SOTSUGYO',
      tag: '完成した道',
      tagColor: 'blue',
      models: shelf2,
    }),
    renderShelf({
      title: 'つくる道',
      enTitle: 'CREATOR',
      tag: 'クリエイティブ',
      tagColor: 'sage',
      models: shelfCreator,
    }),
    renderShelf({
      title: '就活・グローバル',
      enTitle: 'GLOBAL',
      tag: '世界で勝負',
      tagColor: 'vermilion',
      models: shelfShoshaGlobal,
    }),
    renderShelf({
      title: '起業・テックの道',
      enTitle: 'STARTUP',
      tag: 'ゼロイチ',
      tagColor: 'yellow',
      models: shelfStartup,
    }),
    renderShelf({
      title: '研究・専門で進む',
      enTitle: 'SCHOLAR',
      tag: '学問の道',
      tagColor: 'blue',
      models: shelfScholar,
    }),
  ].join('');
}

/** アクセント色：個人色と組み合わせる第2色 */
function getAccentColor(model) {
  const personalColor = getPersonalColor(model);
  // 個人色との組み合わせで識別感が出る色を選ぶ
  const palette = [
    '#f1e8d3', // paper（クリーム）
    '#161616', // ink（黒）
    '#ffd60a', // yellow
  ];
  const handle = (model.handle || model.id || '') + 'accent';
  let hash = 0;
  for (let i = 0; i < handle.length; i++) {
    hash = ((hash << 5) - hash) + handle.charCodeAt(i);
    hash |= 0;
  }
  return palette[Math.abs(hash) % palette.length];
}

/** モデルのデザイン情報を取得（thumb_design があればそれ、なければハッシュベース） */
function getModelDesign(model) {
  if (model.thumb_design) {
    return {
      pattern: model.thumb_design.pattern || 'mono',
      personalColor: model.thumb_design.personal_color || getPersonalColor(model),
      accentColor: model.thumb_design.accent_color || getAccentColor(model),
    };
  }
  return {
    pattern: getThumbPattern(model),
    personalColor: getPersonalColor(model),
    accentColor: getAccentColor(model),
  };
}

/** モデルの「いつから」を返す */
function getModelSince(model) {
  if (model.graduation_year) {
    return `〜${model.graduation_year}`;
  }
  return '2024〜';
}

/** 個人色：handleのハッシュから決める */
function getPersonalColor(model) {
  const colors = [
    '#d63a2f', // vermilion
    '#ffd60a', // yellow
    '#1d3557', // blue
    '#6f8a5e', // sage
    '#e07a3d', // orange
    '#7b4f97', // purple
    '#3d8a8a', // teal
    '#c2548a', // pink
  ];
  const handle = model.handle || model.id || '';
  let hash = 0;
  for (let i = 0; i < handle.length; i++) {
    hash = ((hash << 5) - hash) + handle.charCodeAt(i);
    hash |= 0;
  }
  return colors[Math.abs(hash) % colors.length];
}

/** パターンIDをハンドルから決定（6種類） */
function getThumbPattern(model) {
  const handle = model.handle || model.id || '';
  let hash = 0;
  for (let i = 0; i < handle.length; i++) {
    hash = ((hash << 5) - hash) + handle.charCodeAt(i);
    hash |= 0;
  }
  const patterns = ['mono', 'stripe', 'frame', 'split', 'dot', 'echo'];
  return patterns[Math.abs(hash) % patterns.length];
}

/** 学年ラベル */
function getYearLabel(model) {
  if (model.graduation_year) {
    return `${model.graduation_year}卒`;
  }
  const year = model.current_year;
  if (year === 'daigaku_1') return '大1';
  if (year === 'daigaku_2') return '大2';
  if (year === 'daigaku_3') return '大3';
  if (year === 'daigaku_4') return '大4';
  if (year === 'shakaijin') return '社会人';
  return '';
}

/** 色の明度判定（YIQ法） */
function isLightColor(hex) {
  if (!hex) return false;
  const c = hex.replace('#', '');
  const r = parseInt(c.substr(0, 2), 16);
  const g = parseInt(c.substr(2, 2), 16);
  const b = parseInt(c.substr(4, 2), 16);
  const yiq = (r * 299 + g * 587 + b * 114) / 1000;
  return yiq >= 128;
}

/** URL ハッシュから検索パラメータを取り出す */
function parseSearchParams() {
  const hash = location.hash || '';
  const idx = hash.indexOf('?');
  const params = { keitou: '', status: '', q: '' };
  if (idx < 0) return params;
  const qs = hash.slice(idx + 1);
  qs.split('&').forEach(pair => {
    const [k, v = ''] = pair.split('=');
    if (!k) return;
    params[decodeURIComponent(k)] = decodeURIComponent(v);
  });
  return params;
}

/** フィーチャー対象：reflected が最も多いモデル */
function pickFeaturedModel() {
  return [...Store.models]
    .filter(m => m.cards && m.cards.length > 0)
    .sort((a, b) => {
      const refA = a.cards.filter(c => c.state === 'reflected').length;
      const refB = b.cards.filter(c => c.state === 'reflected').length;
      return refB - refA;
    })[0];
}

/** カードが多いモデル */
function pickProlificModels() {
  return [...Store.models]
    .filter(m => (m.cards || []).length > 0)
    .sort((a, b) => (b.cards?.length || 0) - (a.cards?.length || 0))
    .slice(0, 6);
}

/** 進行中モデル */
function pickShinkochuModels() {
  const featured = pickFeaturedModel();
  return Store.models.filter(m => m.status === 'shinkochu' && m.id !== featured?.id);
}

/** あなたに近いモデル */
function pickSimilarModels(count) {
  const featured = pickFeaturedModel();
  return [...Store.models]
    .filter(m => m.id !== featured?.id)
    .sort((a, b) => {
      if (a.status !== b.status) return a.status === 'shinkochu' ? -1 : 1;
      return 0;
    })
    .slice(0, count);
}

/** 卒業生モデル */
function pickSotsugyoModels() {
  return Store.models.filter(m => m.status === 'sotsugyo');
}

/** 団体プロモ（縮小版） */
function renderHomeOrgPromo() {
  // 団体紹介棚：ロゴを主役に、募集中→その他の順で横スワイプ
  const orgs = [...Store.orgs].sort((a, b) => (b.recruit?.active ? 1 : 0) - (a.recruit?.active ? 1 : 0));
  if (orgs.length === 0) return '';

  const cards = orgs.map(org => {
    const active = Store.models.filter(m => m.status === 'shinkochu' && (m.orgs || []).includes(org.id)).length;
    const alumni = Store.models.filter(m => m.status === 'sotsugyo' && (m.orgs || []).includes(org.id)).length;
    return html`
      <a class="org-card" href="${orgUrl(org.id)}">
        ${org.recruit?.active ? html`<span class="org-card-recruit">★ 募集中</span>` : ''}
        <div class="org-card-logo">${renderOrgEmblem(org, 'emblem-xl')}</div>
        <div class="org-card-type">${esc(org.type_label || '')}</div>
        <div class="org-card-name">${esc(org.name)}</div>
        <div class="org-card-tagline">${esc(org.tagline || '')}</div>
        <div class="org-card-meta">
          <span>${active} ACTIVE</span>
          ${alumni > 0 ? html`<span class="org-card-meta-sep">・</span><span>${alumni} ALUMNI</span>` : ''}
        </div>
      </a>
    `;
  }).join('');

  return html`
    <div class="home-shelf org-shelf">
      <div class="home-shelf-head">
        <div class="home-shelf-title-block">
          <span class="home-shelf-tag home-shelf-tag-yellow">場所</span>
          <span class="home-shelf-title">団体から探す</span>
        </div>
        <span class="home-shelf-en">DANTAI / ${orgs.length}</span>
      </div>
      <div class="home-shelf-row org-shelf-row no-scrollbar">
        ${cards}
      </div>
    </div>
  `;
}

/** 共通モデルサムネ：YouTube風サムネイル */
function renderModelThumb(model) {
  const design = getModelDesign(model);
  const catchphrase = model.thumb_catchphrase || (model.subtitle || '').slice(0, 8);
  const cardCount = (model.cards || []).length;
  const yearLabel = getYearLabel(model);
  const lines = catchphrase.split('\n');
  const lightBg = isLightColor(design.personalColor);

  return html`
    <a class="model-thumb model-thumb-${design.pattern} ${lightBg ? 'model-thumb--light' : ''}" href="${modelUrl(model.id)}"
       style="--personal-color:${design.personalColor}; --accent-color:${design.accentColor};">
      <div class="thumb-base"></div>
      <div class="thumb-pattern-layer">${renderThumbPattern(design.pattern)}</div>
      ${isUpThisWeek(model.id) ? html`<span class="thumb-up-badge">UP!</span>` : ''}
      ${model.character_image ? html`<div class="thumb-character">${renderCharacterImage(model.character_image)}</div>` : ''}
      <div class="thumb-status-corner">${renderStatusPill(model.status, true)}</div>
      <div class="thumb-headline">
        ${lines.map(line => html`<div class="thumb-headline-line">${esc(line)}</div>`).join('')}
      </div>
      <div class="thumb-footer">
        <div class="thumb-footer-name">${esc(model.display_name)}</div>
        <div class="thumb-footer-meta">
          <span class="thumb-footer-handle">${esc(model.handle.toUpperCase())}</span>
          ${cardCount > 0 ? html`<span class="thumb-footer-dot">·</span><span>${cardCount}枚</span>` : ''}
          ${yearLabel ? html`<span class="thumb-footer-dot">·</span><span>${esc(yearLabel)}</span>` : ''}
        </div>
      </div>
    </a>
  `;
}

function renderSearch() {
  const body = document.getElementById('search-body');
  const params = parseSearchParams();
  body.innerHTML = renderSearchContent(params);
  attachSearchEventHandlers(params);
}

/** 検索画面の中身を組み立てる */
function renderSearchContent(params) {
  const filtered = filterModels(params);
  const view = getSearchView(params);

  return [
    renderSearchBar(params),
    renderSearchKeitouChips(params),
    renderSearchStatusChips(params),
    renderSearchResultMeta(filtered, params, view),
    view === 'map' ? renderKeitouMap(filtered, params) : renderSearchResults(filtered),
  ].join('');
}

/** 1棚分のレンダリング */
function renderShelf({ title, enTitle, tag, tagColor, models }) {
  if (!models || models.length === 0) return '';
  return html`
    <div class="home-shelf">
      <div class="home-shelf-head">
        <div class="home-shelf-title-block">
          <span class="home-shelf-tag home-shelf-tag-${tagColor}">${esc(tag)}</span>
          <span class="home-shelf-title">${esc(title)}</span>
        </div>
        <span class="home-shelf-en">${esc(enTitle)} / ${models.length}</span>
      </div>
      <div class="home-shelf-row no-scrollbar">
        ${models.map(m => renderModelThumb(m)).join('')}
      </div>
    </div>
  `;
}

/** パターンごとの装飾レイヤーをレンダリング */
function renderThumbDeco(pattern, initial) {
  switch (pattern) {
    case 'mono':
      // 巨大な頭文字1個だけ、ミニマル
      return html`
        <div class="thumb-deco-mono">
          <span class="thumb-mono-initial">${esc(initial)}</span>
        </div>
      `;

    case 'stripe':
      // 横ストライプ＋頭文字
      return html`
        <div class="thumb-deco-stripe">
          <div class="thumb-stripes"></div>
          <span class="thumb-stripe-initial">${esc(initial)}</span>
        </div>
      `;

    case 'frame':
      // 二重枠 ＋ 中央に小さい頭文字、上部に系統名
      return html`
        <div class="thumb-deco-frame">
          <div class="thumb-frame-outer">
            <span class="thumb-frame-initial">${esc(initial)}</span>
          </div>
        </div>
      `;

    case 'split':
      // 上下2色分割＋頭文字を中央にまたぐ
      return html`
        <div class="thumb-deco-split">
          <div class="thumb-split-top"></div>
          <div class="thumb-split-bottom"></div>
          <span class="thumb-split-initial">${esc(initial)}</span>
        </div>
      `;

    case 'dot':
      // ドットマトリックス＋アウトライン頭文字
      return html`
        <div class="thumb-deco-dot">
          <div class="thumb-dot-grid"></div>
          <span class="thumb-dot-initial">${esc(initial)}</span>
        </div>
      `;

    case 'echo':
      // 頭文字を多重化（3つずらして重ねる）
      return html`
        <div class="thumb-deco-echo">
          <span class="thumb-echo-1">${esc(initial)}</span>
          <span class="thumb-echo-2">${esc(initial)}</span>
          <span class="thumb-echo-3">${esc(initial)}</span>
        </div>
      `;

    default:
      return html`<span class="thumb-mono-initial">${esc(initial)}</span>`;
  }
}

/** パターン背景レイヤー（テキストとキャラから外したシンプル版） */
function renderThumbPattern(pattern) {
  switch (pattern) {
    case 'stripe':
      return html`<div class="pattern-stripe"></div>`;
    case 'dot':
      return html`<div class="pattern-dot"></div>`;
    case 'frame':
      return html`<div class="pattern-frame"></div>`;
    case 'split':
      return html`<div class="pattern-split-top"></div><div class="pattern-split-bottom"></div>`;
    case 'echo':
      return html`<div class="pattern-echo"></div>`;
    case 'mono':
    default:
      return html`<div class="pattern-mono"></div>`;
  }
}

/** 団体名を短く */
function shortenOrgName(name) {
  const idx = name.indexOf('「');
  return idx > 0 ? name.slice(0, idx) : name;
}

/** 現在の検索条件を URL に書き戻す（ナビゲートではなくreplaceで） */
/** サンドボックス用：直後の hashchange による二重描画を抑制するフラグ */
let __suppressNextRouteRender = false;

function updateSearchParams(updates) {
  const current = parseSearchParams();
  const next = { ...current, ...updates };
  // 空の値は削除
  Object.keys(next).forEach(k => {
    if (next[k] === '' || next[k] == null) delete next[k];
  });
  const qs = Object.entries(next)
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
    .join('&');
  const newHash = qs ? `#/search?${qs}` : '#/search';
  if (location.hash !== newHash) {
    try {
      // 履歴を汚さずにURLを書き換えて再描画
      history.replaceState(null, '', newHash);
      handleRouteChange();
    } catch (e) {
      // サンドボックス環境（claude.ai artifact等のsrcdoc iframe）では
      // replaceState が SecurityError になるため、hash直接代入にフォールバック。
      // その場で同期的に再描画し、直後に来る hashchange による二重描画は抑制する。
      __suppressNextRouteRender = true;
      location.hash = newHash;
      handleRouteChange();
    }
  }
}



/** 表示モードを決める：明示指定 > テキスト検索中はリスト > デフォルトはマップ */
function getSearchView(params) {
  if (params.view === 'map' || params.view === 'list') return params.view;
  if (params.q && params.q.trim()) return 'list';
  return 'map';
}

/** モデルをフィルタする */
function filterModels(params) {
  let models = [...Store.models];

  // 系統
  if (params.keitou) {
    models = models.filter(m => (m.keitou || []).includes(params.keitou));
  }

  // ステータス
  if (params.status) {
    models = models.filter(m => m.status === params.status);
  }

  // フリーテキスト
  if (params.q && params.q.trim()) {
    const q = params.q.trim().toLowerCase();
    models = models.filter(m => {
      const hay = [
        m.display_name,
        m.subtitle,
        m.bio,
        m.handle,
        ...(m.cards || []).map(c => c.what + ' ' + (c.why || '')),
      ].join(' ').toLowerCase();
      return hay.includes(q);
    });
  }

  // ソート：reflected が多い順、shinkochu優先
  models.sort((a, b) => {
    const refA = (a.cards || []).filter(c => c.state === 'reflected').length;
    const refB = (b.cards || []).filter(c => c.state === 'reflected').length;
    if (refA !== refB) return refB - refA;
    if (a.status !== b.status) return a.status === 'shinkochu' ? -1 : 1;
    return 0;
  });

  return models;
}

/** 検索バー */
function renderSearchBar(params) {
  return html`
    <div class="search-bar-wrap">
      <span class="search-icon-big">⌕</span>
      <input class="search-input" type="text"
             id="search-text-input"
             value="${esc(params.q || '')}"
             placeholder="名前・学部・職種・テーマで探す">
      ${params.q ? html`<button class="search-clear" onclick="clearSearchText()" aria-label="クリア">✕</button>` : ''}
    </div>
  `;
}

/** 系統フィルタチップ */
function renderSearchKeitouChips(params) {
  const current = params.keitou || '';
  const allChip = { id: '', label: 'すべて' };
  const keitouChips = Store.keitou.map(k => ({ id: k.id, label: k.label_en }));

  // 選択中のチップを先頭近くに持ってくる（「すべて」のすぐ後ろ）
  let chips;
  if (current && current !== '') {
    const active = keitouChips.find(c => c.id === current);
    const others = keitouChips.filter(c => c.id !== current);
    chips = [allChip, active, ...others].filter(Boolean);
  } else {
    chips = [allChip, ...keitouChips];
  }

  return html`
    <div class="search-filter-section">
      <div class="search-filter-label">KEITOU / 系統</div>
      <div class="search-chips-row no-scrollbar">
        ${chips.map(c => html`
          <button class="search-chip ${current === c.id ? 'search-chip-active' : ''}"
                  onclick="handleSearchKeitouChange('${esc(c.id)}')">
            ${c.id ? html`<span class="keitou-dot keitou-dot--${esc(c.id)}"></span>` : html`<span class="keitou-dot" style="background:var(--paper);"></span>`}
            <span>${esc(c.label)}</span>
          </button>
        `).join('')}
      </div>
    </div>
  `;
}

/** ステータスフィルタ */
function renderSearchStatusChips(params) {
  const current = params.status || '';
  const options = [
    { id: '', label: '両方' },
    { id: 'shinkochu', label: 'SHINKOCHU 進行中' },
    { id: 'sotsugyo', label: 'SOTSUGYO 卒業生' },
  ];

  return html`
    <div class="search-filter-section">
      <div class="search-filter-label">STATUS / 状態</div>
      <div class="search-chips-row no-scrollbar">
        ${options.map(o => html`
          <button class="search-chip ${current === o.id ? 'search-chip-active' : ''}"
                  onclick="handleSearchStatusChange('${esc(o.id)}')">
            <span>${esc(o.label)}</span>
          </button>
        `).join('')}
      </div>
    </div>
  `;
}

/** 結果数メタ */
function renderSearchResultMeta(filtered, params, view = 'list') {
  const hasFilter = params.keitou || params.status || params.q;
  return html`
    <div class="search-result-meta">
      <div class="search-result-count">
        <span class="search-result-num">${filtered.length}</span>
        <span class="search-result-label">名</span>
      </div>
      ${hasFilter
        ? html`<button class="search-reset" onclick="resetSearchFilters()">条件をリセット</button>`
        : ''}
      <div class="search-view-toggle">
        <button class="search-view-btn ${view === 'map' ? 'search-view-btn-active' : ''}"
                onclick="setSearchView('map')">⊞ MAP</button>
        <button class="search-view-btn ${view === 'list' ? 'search-view-btn-active' : ''}"
                onclick="setSearchView('list')">☰ LIST</button>
      </div>
    </div>
  `;
}

/* ========== 系統マップ（探すタブのMAPビュー） ========== */

/** ゾーン定義：x,y,w,h は%。系統の「領土」 */
const MAP_ZONES = [
  { id: 'creator', label: 'CREATOR', jp: 'つくる',   x: 3,  y: 15, w: 52, h: 56, cls: 'zone-creator', rot: -1.2 },
  { id: 'shosha',  label: 'SHOSHA',  jp: '組織で動く', x: 50, y: 3,  w: 47, h: 33, cls: 'zone-shosha',  rot: 0.8 },
  { id: 'global',  label: 'GLOBAL',  jp: '世界へ',   x: 57, y: 39, w: 40, h: 33, cls: 'zone-global zone-label-bl',  rot: -0.6 },
  { id: 'scholar', label: 'SCHOLAR', jp: 'きわめる',  x: 39, y: 74, w: 58, h: 23, cls: 'zone-scholar zone-label-br', rot: 0.5 },
  { id: 'startup', label: 'STARTUP', jp: 'おこす',   x: 3,  y: 74, w: 33, h: 23, cls: 'zone-startup', rot: -0.8 },
];

/** モデル配置（x,y は%）と顔クロップ（背景の位置/拡大率） */
const MAP_PLACEMENT = {
  // CREATOR
  aika_films:    { x: 18, y: 31, face: { px: 36, py: 26, zoom: 230 } },
  kaito_doc:     { x: 12, y: 54, face: { px: 44, py: 24, zoom: 230 } },
  minami_edit:   { x: 30, y: 60, face: { px: 66, py: 34, zoom: 240 } },
  ryo_director:  { x: 39, y: 36, face: { px: 50, py: 34, zoom: 220 } },
  ren_design:    { x: 32, y: 20, face: { px: 58, py: 24, zoom: 240 } },
  // CREATOR×SCHOLAR 境界
  kotoha_pen:    { x: 46, y: 68, face: { px: 46, py: 26, zoom: 250 } },
  // SHOSHA
  nana_cm:       { x: 55, y: 22, face: { px: 46, py: 22, zoom: 240 } },
  hikaru_fin:    { x: 78, y: 15, face: { px: 48, py: 18, zoom: 240 } },
  // SHOSHA×GLOBAL 境界
  mei_boeki:     { x: 86, y: 35, face: { px: 44, py: 18, zoom: 250 } },
  saya_global:   { x: 68, y: 40, face: { px: 56, py: 28, zoom: 240 } },
  rina_athlete:  { x: 88, y: 58, face: { px: 36, py: 24, zoom: 245 } },
  // GLOBAL
  aoi_ngo:       { x: 62, y: 57, face: { px: 38, py: 14, zoom: 250 } },
  // SCHOLAR
  haru_scholar:  { x: 57, y: 82, face: { px: 42, py: 22, zoom: 240 } },
  jun_lab:       { x: 70, y: 90, face: { px: 50, py: 36, zoom: 230 } },
  // STARTUP×SCHOLAR 境界
  takumi_hybrid: { x: 35, y: 81, face: { px: 52, py: 46, zoom: 230 } },
  yuki_dev:      { x: 47, y: 90, face: { px: 42, py: 26, zoom: 240 } },
  // STARTUP
  daichi_agri:   { x: 14, y: 87, face: { px: 46, py: 12, zoom: 250 } },
  sora_app:      { x: 26, y: 93, face: { px: 44, py: 22, zoom: 250 } },
};

/** マップ本体 */
function renderKeitouMap(filtered, params) {
  const matchIds = new Set(filtered.map(m => m.id));

  const zones = MAP_ZONES.map(z => html`
    <div class="map-zone ${z.cls} ${params.keitou && params.keitou !== z.id ? 'map-zone-dim' : ''}"
         style="left:${z.x}%; top:${z.y}%; width:${z.w}%; height:${z.h}%; transform:rotate(${z.rot}deg);">
      <span class="map-zone-label">${esc(z.label)}</span>
      <span class="map-zone-jp">${esc(z.jp)}</span>
    </div>
  `).join('');

  const icons = Store.models.map(model => {
    const pos = MAP_PLACEMENT[model.id];
    if (!pos) return '';
    const dim = !matchIds.has(model.id);
    const img = model.character_image || '';
    const imgUrl = img.startsWith('data:') ? img : img.replace(/\.png$/, '.webp');
    const face = pos.face || { px: 50, py: 15, zoom: 240 };
    const design = getModelDesign(model);
    return html`
      <button class="map-icon ${dim ? 'map-icon-dim' : ''}"
              id="map-icon-${esc(model.id)}"
              style="left:${pos.x}%; top:${pos.y}%; --icon-ring:${design.personalColor};"
              onclick="handleMapIconTap('${esc(model.id)}')"
              aria-label="${esc(model.display_name)}">
        <span class="map-icon-img" style="background-image:url('${imgUrl}'); background-size:${face.zoom}%; background-position:${face.px}% ${face.py}%;"></span>
        ${model.status === 'shinkochu'
          ? html`<span class="map-icon-badge map-icon-badge-now"></span>`
          : html`<span class="map-icon-badge map-icon-badge-grad">卒</span>`}
        <span class="map-icon-name">${esc(model.display_name)}</span>
      </button>
    `;
  }).join('');

  return html`
    <div class="keitou-map-wrap">
      <div class="keitou-map" id="keitou-map">
        <div class="keitou-map-grid"></div>
        ${zones}
        ${icons}
        <div class="map-minicard" id="map-minicard"></div>
      </div>
      <div class="keitou-map-legend">
        <span class="map-legend-item"><span class="map-legend-dot-now"></span>進行中</span>
        <span class="map-legend-item"><span class="map-legend-dot-grad">卒</span>卒業生</span>
        <span class="map-legend-hint">境界上の人は2つの系統をまたいでいます</span>
      </div>
    </div>
  `;
}

/** マップアイコンのタップ → ミニカード表示（同じ人を再タップで詳細へ） */
window.handleMapIconTap = function(modelId) {
  const card = document.getElementById('map-minicard');
  if (!card) return;
  const model = getModel(modelId);
  if (!model) return;

  // 同じ人を再タップ → 詳細ページへ
  if (card.dataset.modelId === modelId) {
    navigateTo(modelUrl(modelId));
    return;
  }

  // 選択状態の付け替え
  document.querySelectorAll('.map-icon-selected').forEach(el => el.classList.remove('map-icon-selected'));
  const icon = document.getElementById(`map-icon-${modelId}`);
  if (icon) icon.classList.add('map-icon-selected');

  const cardCount = (model.cards || []).length;
  const yearLabel = getYearLabel(model);
  // 下段のアイコンを選んだときはミニカードを上に出す（アイコンを覆わないように）
  const pos = MAP_PLACEMENT[modelId];
  card.classList.toggle('map-minicard-top', !!pos && pos.y > 62);
  card.dataset.modelId = modelId;
  card.innerHTML = html`
    <a class="map-minicard-inner" href="${modelUrl(modelId)}">
      <span class="map-minicard-name-block">
        <span class="map-minicard-name">${esc(model.display_name)}</span>
        <span class="map-minicard-subtitle">${esc(model.subtitle)}</span>
        <span class="map-minicard-meta">${cardCount > 0 ? cardCount + '枚' : ''}${cardCount > 0 && yearLabel ? ' ・ ' : ''}${yearLabel ? esc(yearLabel) : ''}</span>
      </span>
      <span class="map-minicard-arrow">▶</span>
    </a>
  `;
  card.classList.add('map-minicard-show');
};

window.setSearchView = function(view) {
  updateSearchParams({ view });
};

/** 結果リスト */
function renderSearchResults(filtered) {
  if (filtered.length === 0) {
    return html`
      <div class="search-empty">
        <div class="search-empty-icon">ⓘ</div>
        <div class="search-empty-title">該当なし</div>
        <div class="search-empty-body">
          条件を緩めると、もっと先輩が見つかります。<br>
          ・系統を変えてみる<br>
          ・ステータスを「両方」にする<br>
          ・検索ワードを短くする
        </div>
      </div>
    `;
  }

  return html`
    <div class="search-result-list">
      ${filtered.map(m => renderSearchResultCard(m)).join('')}
    </div>
  `;
}

function renderSearchResultCard(model) {
  const cardCount = (model.cards || []).length;
  const reflected = (model.cards || []).filter(c => c.state === 'reflected').length;
  const yearLabel = getYearLabel(model);
  const keitouLabel = (model.keitou || []).map(k => getKeitou(k)?.label_en).filter(Boolean).join(' × ');
  const orgsLabel = (model.orgs || []).map(o => shortenOrgName(getOrg(o)?.name || '')).filter(Boolean).join(' ・ ');

  return html`
    <a class="search-result-card" href="${modelUrl(model.id)}">
      <div class="search-result-row">
        ${renderAvatar(model, 'md')}
        <div class="search-result-text">
          <div class="search-result-meta-row">
            ${renderStatusPill(model.status)}
            ${keitouLabel ? html`<span class="pill pill-sage-pale" style="font-size:9px;">${esc(keitouLabel)}</span>` : ''}
          </div>
          <div class="search-result-handle">${esc(model.handle.toUpperCase())}</div>
          <div class="search-result-name">${esc(model.display_name)}</div>
          <div class="search-result-subtitle">${esc(model.subtitle)}</div>
          <div class="search-result-stats">
            <span><strong>${cardCount}</strong> CARDS</span>
            ${reflected > 0 ? html`<span><strong>${reflected}</strong> ふりかえり済み</span>` : ''}
            <span>${esc(yearLabel)}</span>
            ${orgsLabel ? html`<span>・ ${esc(orgsLabel)}</span>` : ''}
          </div>
        </div>
        <span class="search-result-arrow">▸</span>
      </div>
    </a>
  `;
}

/** 検索イベントハンドラの紐づけ */
function attachSearchEventHandlers(params) {
  const input = document.getElementById('search-text-input');
  if (!input) return;

  // 入力で即座にフィルタ（デバウンス）
  let debounceTimer = null;
  input.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      updateSearchParams({ q: input.value });
      // 再描画後、フォーカスを復元
      const newInput = document.getElementById('search-text-input');
      if (newInput) {
        newInput.focus();
        // カーソルを末尾に
        newInput.setSelectionRange(newInput.value.length, newInput.value.length);
      }
    }, 250);
  });
}

window.handleSearchKeitouChange = function(keitouId) {
  updateSearchParams({ keitou: keitouId });
};

window.handleSearchStatusChange = function(status) {
  updateSearchParams({ status });
};

window.resetSearchFilters = function() {
  updateSearchParams({ keitou: '', status: '', q: '' });
};

window.clearSearchText = function() {
  updateSearchParams({ q: '' });
};

function renderPlan() {
  const body = document.getElementById('plan-body');
  body.innerHTML = renderPlanContent();

  // セレクトの onchange を後付け
  attachPlanEventHandlers();
}

/** 計画ページの中身を組み立てる */
function renderPlanContent() {
  const cards = Store.userPlan.cards || [];

  if (cards.length === 0) {
    return [
      renderPlanNotifBar(),
      renderPlanTasks(),
      renderPlanEmpty(),
    ].join('');
  }

  return [
    renderPlanNotifBar(),
    renderPlanTasks(),
    renderPlanHeader(cards),
    renderPlanReadinessBand(),
    renderPlanConflictBanners(cards),
    renderPlanTimeline(cards),
    renderPlanAddRow(),
    renderPlanApplyCTA(),
  ].join('');
}

/** 空っぽ状態：まだカードがない */
/** カード追加の二択（計画にカードがある状態用） */
function renderPlanAddRow() {
  return html`
    <div class="plan-add-row">
      <a class="plan-add-btn plan-add-self" href="#/create">✎ じぶんで書く</a>
      <a class="plan-add-btn" href="#/home">⌕ 先輩から借りる</a>
    </div>
  `;
}

function renderPlanEmpty() {
  return html`
    <div class="plan-header">
      <div class="plan-title">わたしの大学計画</div>
      <div class="plan-meta">まだカードがありません</div>
    </div>
    <div class="plan-choice">
      <div class="plan-choice-lead">最初の1枚、どこから始める？</div>
      <div class="plan-choice-grid">
        <a class="plan-choice-card plan-choice-self" href="#/create">
          <div class="plan-choice-icon">✎</div>
          <div class="plan-choice-title">じぶんで立てる</div>
          <div class="plan-choice-body">頭の中にあるやりたいことを、白紙からカードに書く。</div>
          <div class="plan-choice-cta">▶ オリジナルカードを書く</div>
        </a>
        <a class="plan-choice-card plan-choice-borrow" href="#/home">
          <div class="plan-choice-icon">⌕</div>
          <div class="plan-choice-title">先輩の力を借りる</div>
          <div class="plan-choice-body">18人の先輩の道筋から、気に入った行動を保存してアレンジ。</div>
          <div class="plan-choice-cta">▶ 先輩を探す</div>
        </a>
      </div>
      <div class="plan-choice-note">どちらで作っても、あとから混ぜられます</div>
    </div>
  `;
}

/** ヘッダー */
/* ============================================================
   タスク管理 ＆ 通知（計画タブ）
   ============================================================ */

let __notifPanelOpen = false;
let __taskDoneOpen = false;

function getTasks() {
  if (!Store.userPlan.tasks) Store.userPlan.tasks = [];
  return Store.userPlan.tasks;
}

function todayStr(offsetDays = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

/** 期限の状態を判定: overdue / today / tomorrow / future / none */
function taskDueState(task) {
  if (!task.due) return 'none';
  const today = todayStr();
  if (task.due < today) return 'overdue';
  if (task.due === today) return 'today';
  if (task.due === todayStr(1)) return 'tomorrow';
  return 'future';
}

function formatDue(due) {
  if (!due) return '';
  const [y, m, d] = due.split('-');
  return `${parseInt(m)}/${parseInt(d)}`;
}

/** 通知の導出（未完了タスクの期限から自動生成） */
function getNotifications() {
  const dismissed = new Set(Store.userPlan.notif_dismissed || []);
  const items = [];
  for (const t of getTasks()) {
    if (t.done) continue;
    const state = taskDueState(t);
    if (state === 'overdue') {
      const days = Math.round((new Date(todayStr()) - new Date(t.due)) / 86400000);
      items.push({ key: `task-overdue-${t.id}-${t.due}`, level: 'warn',
                   text: `期限切れ: ${t.text}`, sub: `${formatDue(t.due)}（${days}日超過）`, taskId: t.id });
    } else if (state === 'today') {
      items.push({ key: `task-today-${t.id}-${t.due}`, level: 'warn',
                   text: `今日まで: ${t.text}`, sub: '今日が期限です', taskId: t.id });
    } else if (state === 'tomorrow') {
      items.push({ key: `task-tomorrow-${t.id}-${t.due}`, level: 'info',
                   text: `明日まで: ${t.text}`, sub: `${formatDue(t.due)} が期限`, taskId: t.id });
    }
  }
  return items.filter(n => !dismissed.has(n.key));
}

/** 通知バー（通知がある時だけ表示） */
function renderPlanNotifBar() {
  const notifs = getNotifications();
  if (notifs.length === 0) return '';
  const warnCount = notifs.filter(n => n.level === 'warn').length;

  return html`
    <div class="notif-band ${warnCount > 0 ? 'notif-band-warn' : ''}">
      <button class="notif-band-head" onclick="toggleNotifPanel()">
        <span class="notif-bell">🔔</span>
        <span class="notif-band-title">通知</span>
        <span class="notif-count">${notifs.length}</span>
        <span class="notif-band-toggle">${__notifPanelOpen ? '−' : '＋'}</span>
      </button>
      ${__notifPanelOpen ? html`
        <div class="notif-list">
          ${notifs.map(n => html`
            <div class="notif-item notif-item-${n.level}">
              <div class="notif-item-text">
                <div class="notif-item-main">${esc(n.text)}</div>
                <div class="notif-item-sub">${esc(n.sub)}</div>
              </div>
              <button class="notif-dismiss" onclick="dismissNotif('${esc(n.key)}')" aria-label="既読にする">✓</button>
            </div>
          `).join('')}
          <button class="notif-dismiss-all" onclick="dismissAllNotifs()">すべて既読にする</button>
        </div>
      ` : ''}
    </div>
  `;
}

/** タスクセクション */
function renderPlanTasks() {
  const tasks = getTasks();
  const active = tasks.filter(t => !t.done)
    .sort((a, b) => (a.due || '9999') < (b.due || '9999') ? -1 : 1);
  const done = tasks.filter(t => t.done);
  const total = tasks.length;
  const pct = total > 0 ? Math.round(done.length / total * 100) : 0;

  const dueBadge = (t) => {
    const s = taskDueState(t);
    if (s === 'overdue') return html`<span class="task-due task-due-overdue">${formatDue(t.due)} 期限切れ</span>`;
    if (s === 'today') return html`<span class="task-due task-due-today">今日まで</span>`;
    if (s === 'tomorrow') return html`<span class="task-due task-due-soon">明日まで</span>`;
    if (s === 'future') return html`<span class="task-due">${formatDue(t.due)}</span>`;
    return '';
  };

  return html`
    <div class="task-section">
      <div class="task-section-head">
        <span class="task-section-title">TASKS / やること</span>
        ${total > 0 ? html`
          <span class="task-progress-label">${done.length}/${total}</span>
        ` : ''}
      </div>
      ${total > 0 ? html`
        <div class="task-progress"><div class="task-progress-fill" style="width:${pct}%"></div></div>
      ` : ''}

      <div class="task-add-row">
        <input class="task-input" id="task-input" type="text" placeholder="やることを追加"
               onkeydown="if(event.key==='Enter')handleTaskAdd()">
        <input class="task-date" id="task-due" type="date" aria-label="期限">
        <button class="task-add-btn" onclick="handleTaskAdd()">＋</button>
      </div>

      ${active.length === 0 && done.length === 0 ? html`
        <div class="task-empty">まだタスクがありません。計画を小さな一歩に分解しましょう。</div>
      ` : ''}

      ${active.map(t => html`
        <div class="task-row">
          <button class="task-check" onclick="handleTaskToggle('${esc(t.id)}')" aria-label="完了にする"></button>
          <span class="task-text">${esc(t.text)}</span>
          ${dueBadge(t)}
          <button class="task-del" onclick="handleTaskDelete('${esc(t.id)}')" aria-label="削除">✕</button>
        </div>
      `).join('')}

      ${done.length > 0 ? html`
        <details class="task-done-fold" ${__taskDoneOpen ? 'open' : ''} ontoggle="__taskDoneOpen=this.open">
          <summary class="task-done-summary">完了済み ${done.length}</summary>
          ${done.map(t => html`
            <div class="task-row task-row-done">
              <button class="task-check task-check-on" onclick="handleTaskToggle('${esc(t.id)}')" aria-label="未完了に戻す">✓</button>
              <span class="task-text">${esc(t.text)}</span>
              <button class="task-del" onclick="handleTaskDelete('${esc(t.id)}')" aria-label="削除">✕</button>
            </div>
          `).join('')}
        </details>
      ` : ''}
    </div>
  `;
}

/* --- タスク操作 --- */
window.handleTaskAdd = function() {
  const input = document.getElementById('task-input');
  const dueEl = document.getElementById('task-due');
  const text = (input?.value || '').trim();
  if (!text) { input?.focus(); return; }
  getTasks().push({
    id: 'task_' + Date.now().toString(36),
    text,
    due: dueEl?.value || null,
    done: false,
    created_at: new Date().toISOString(),
  });
  saveUserPlan();
  renderPlan();
  const newInput = document.getElementById('task-input');
  if (newInput) newInput.focus();
};

window.handleTaskToggle = function(taskId) {
  const t = getTasks().find(x => x.id === taskId);
  if (!t) return;
  t.done = !t.done;
  t.done_at = t.done ? new Date().toISOString() : null;
  saveUserPlan();
  renderPlan();
  if (t.done) showToast('タスク完了！', 'success');
};

window.handleTaskDelete = function(taskId) {
  Store.userPlan.tasks = getTasks().filter(x => x.id !== taskId);
  saveUserPlan();
  renderPlan();
};

/* --- 通知操作 --- */
window.toggleNotifPanel = function() {
  __notifPanelOpen = !__notifPanelOpen;
  renderPlan();
};

window.dismissNotif = function(key) {
  if (!Store.userPlan.notif_dismissed) Store.userPlan.notif_dismissed = [];
  Store.userPlan.notif_dismissed.push(key);
  saveUserPlan();
  renderPlan();
};

window.dismissAllNotifs = function() {
  if (!Store.userPlan.notif_dismissed) Store.userPlan.notif_dismissed = [];
  getNotifications().forEach(n => Store.userPlan.notif_dismissed.push(n.key));
  saveUserPlan();
  renderPlan();
};

/* --- ブラウザ通知（対応環境のみ・設定でON） --- */
function browserNotifSupported() {
  try { return typeof Notification !== 'undefined' && !!Notification.requestPermission; }
  catch (e) { return false; }
}

window.handleBrowserNotifToggle = async function() {
  if (!browserNotifSupported()) {
    showToast('この環境ではブラウザ通知を利用できません', 'warn');
    return;
  }
  if (Store.userPlan.notif_browser) {
    Store.userPlan.notif_browser = false;
    saveUserPlan();
    showToast('ブラウザ通知をオフにしました');
  } else {
    try {
      const perm = await Notification.requestPermission();
      if (perm === 'granted') {
        Store.userPlan.notif_browser = true;
        saveUserPlan();
        showToast('ブラウザ通知をオンにしました', 'success');
        runBrowserNotifications();
      } else {
        showToast('通知が許可されませんでした', 'warn');
      }
    } catch (e) {
      showToast('この環境ではブラウザ通知を利用できません', 'warn');
    }
  }
  if (location.hash === '#/settings') renderSettings();
};

/** 期限切れ/今日のタスクをブラウザ通知（1タスク1日1回まで） */
function runBrowserNotifications() {
  try {
    if (!Store.userPlan?.notif_browser) return;
    if (!browserNotifSupported() || Notification.permission !== 'granted') return;
    const today = todayStr();
    let fired = 0;
    for (const t of getTasks()) {
      if (t.done || fired >= 3) continue;
      const state = taskDueState(t);
      if ((state === 'overdue' || state === 'today') && t.notified_on !== today) {
        new Notification('ダイハック', {
          body: state === 'today' ? `今日まで: ${t.text}` : `期限切れ: ${t.text}（${formatDue(t.due)}）`,
          tag: `daihack-task-${t.id}`,
        });
        t.notified_on = today;
        fired++;
      }
    }
    if (fired > 0) saveUserPlan();
  } catch (e) {
    // 通知が使えない環境では静かに無視
  }
}

function renderPlanHeader(cards) {
  const reflectedCount = cards.filter(c => c.state === 'reflected').length;
  const plannedCount = cards.filter(c => c.state === 'planned').length;
  return html`
    <div class="plan-header">
      <div class="plan-title">わたしの大学計画</div>
      <div class="plan-meta">
        ふりかえり済み ${reflectedCount} ・ 予定 ${plannedCount}
      </div>
    </div>
  `;
}

/** READINESS 帯 */
function renderPlanReadinessBand() {
  const r = checkReadiness();
  const labels = {
    spans_multiple_terms: '2つ以上の学期にカード',
    all_cards_have_why: 'ふりかえりが書けている',
    majority_remixed_why: '自分の言葉で remix',
    has_original_card: 'オリジナルが1枚以上',
  };

  return html`
    <div class="plan-readiness">
      <div class="plan-readiness-head">
        <span class="plan-readiness-label">READINESS / 申請レディネス</span>
        <span class="plan-readiness-count">${r.conditions_met} / ${r.total_conditions}</span>
      </div>
      <div class="plan-readiness-conditions">
        ${Object.keys(labels).map(key => {
          const met = r.conditions[key];
          return html`
            <div class="plan-readiness-row ${met ? 'plan-readiness-row-met' : ''}">
              <span class="plan-readiness-check">${met ? '✓' : '○'}</span>
              <span class="plan-readiness-text">${esc(labels[key])}</span>
            </div>
          `;
        }).join('')}
      </div>
    </div>
  `;
}

/** 衝突警告バナー（必要な場合のみ） */
function renderPlanConflictBanners(cards) {
  const conflicts = detectConflicts(cards);
  if (conflicts.length === 0) return '';

  // 意図的に受け入れた衝突は表示しない
  const intentional = new Set((Store.userPlan.intentional_overlaps || []).map(o => o.key));
  const visibleConflicts = conflicts.filter(c => !intentional.has(c.key));

  if (visibleConflicts.length === 0) return '';

  return visibleConflicts.map(c => html`
    <div class="plan-conflict-banner">
      <span class="plan-conflict-icon">⚠</span>
      <span class="plan-conflict-text">
        ${esc(c.eraLabel)}に長い活動が ${c.cards.length} つ重なっています
      </span>
      <button class="plan-conflict-btn" onclick="openConflictSheet('${esc(c.key)}')">詳しく</button>
    </div>
  `).join('');
}

/** タイムライン本体 */
function renderPlanTimeline(cards) {
  // カードを era ごとにグループ化
  const byEra = {};
  cards.forEach(c => {
    const era = STAGE_TO_ERA[c.when?.stage] || 'unknown';
    if (!byEra[era]) byEra[era] = [];
    byEra[era].push(c);
  });

  // 表示する era：実際にカードがある era ＋ 大学の各学年（空白枠を出すため）
  const allEras = ['kokou', 'daigaku_1', 'daigaku_2', 'daigaku_3', 'daigaku_4', 'shakaijin'];

  // 「いま」がどの era か（ユーザープロファイルから、なければ大学1年とする）
  const currentEra = Store.userPlan.profile?.current_year || 'daigaku_1';
  const currentEraNorm = STAGE_TO_ERA[currentEra + '_zenki'] || currentEra;

  // 'pre' 時代にカードがあれば先頭に追加
  const erasToShow = (byEra['pre']?.length > 0 ? ['pre'] : []).concat(allEras);

  return html`
    <div class="plan-timeline">
      ${erasToShow.map(era => renderPlanEra(era, byEra[era] || [], currentEraNorm, cards)).join('')}
    </div>
  `;
}

/** タイムラインの 1 era 分 */
function renderPlanEra(era, eraCards, currentEra, allCards) {
  const isCurrent = era === currentEra;
  const isPast = ERA_ORDER.indexOf(era) < ERA_ORDER.indexOf(currentEra);
  const isFuture = ERA_ORDER.indexOf(era) > ERA_ORDER.indexOf(currentEra);
  const eraLabel = ERA_LABEL[era] || era;

  // この era をまたぐレーンバーを集める（前の era から続いているもの含む）
  const lanesInEra = computeLanesForEra(era, allCards);

  // 高校以前は折りたたみ
  if (era === 'pre' || era === 'kokou') {
    return renderPlanEraCollapsed(era, eraCards);
  }

  return html`
    <div class="plan-era">
      <div class="plan-era-row">
        <div class="plan-spine">
          ${isCurrent
            ? html`<div class="plan-spine-now">いま</div>`
            : html`<div class="plan-spine-dot ${isFuture ? 'plan-spine-dot-future' : ''}"></div>`}
          ${lanesInEra.map((lane, i) => html`
            <div class="plan-lane-bar" style="background:${esc(lane.color)}; left:${22 + i * 9}px; top:${esc(lane.top)}px; height:${esc(lane.height)}px;"></div>
          `).join('')}
        </div>
        <div class="plan-era-content">
          <div class="plan-era-title">${esc(eraLabel)}</div>
          ${eraCards.length === 0
            ? renderPlanEmptySlot(era)
            : eraCards.map(c => renderPlanCard(c)).join('')}
        </div>
      </div>
    </div>
  `;
}

/** 高校時代の折りたたみ */
function renderPlanEraCollapsed(era, eraCards) {
  if (eraCards.length === 0) return '';
  const eraLabel = ERA_LABEL[era] || era;
  return html`
    <details class="plan-era-collapsed">
      <summary>
        <span class="plan-era-collapsed-icon">⌒</span>
        <span class="plan-era-collapsed-title">${esc(eraLabel)}</span>
        <span class="plan-era-collapsed-meta">カード ${eraCards.length} 枚</span>
        <span class="plan-era-collapsed-toggle">＋</span>
      </summary>
      <div class="plan-era-collapsed-body">
        ${eraCards.map(c => renderPlanCard(c)).join('')}
      </div>
    </details>
  `;
}

/** 空白学年プレースホルダー */
function renderPlanEmptySlot(era) {
  const eid = era?.id || era || '';
  const preStage = STAGE_LABEL[`${eid}_zenki`] ? `${eid}_zenki` : '';
  return html`
    <div class="plan-empty-slot">
      <div class="plan-empty-slot-text">まだ予定がありません</div>
      <div class="plan-empty-slot-actions">
        <a class="plan-empty-slot-btn" href="#/create${preStage ? `?stage=${preStage}` : ''}">✎ じぶんで書く</a>
        <a class="plan-empty-slot-btn" href="#/home">⌕ 先輩から借りる</a>
      </div>
    </div>
  `;
}

/** 計画ページのカード1枚 */
function renderPlanCard(card) {
  const stageLbl = stageLabel(card.when?.stage) || '';
  const duration = card.when?.duration || '';
  const isPlanned = card.state === 'planned';
  const stateLabel = isPlanned ? '予定' : 'ふりかえり済み';

  return html`
    <div class="plan-card ${isPlanned ? 'plan-card-planned' : 'plan-card-reflected'}" onclick="openPlanCardSheet('${esc(card.id)}')">
      <div class="card-stripe stripe-${esc(card.category || 'skill')}"></div>
      <div class="card-body">
        <div class="card-meta-row">
          <span class="when-pill">${esc(stageLbl)}</span>
          ${duration ? html`<span class="duration-pill">${esc(duration)}</span>` : ''}
          <span class="plan-state-pill ${isPlanned ? 'plan-state-planned' : 'plan-state-reflected'}">${esc(stateLabel)}</span>
        </div>
        <div class="card-what">${esc(card.what)}</div>
        ${card.why ? html`
          <div class="plan-why-line">ねらい — ${esc(truncate(card.why, 50))}</div>
        ` : ''}
        ${renderCardResult(card)}
        ${card.parent_handle
          ? html`<span class="from-chip">${esc(card.parent_handle)}をアレンジ</span>`
          : html`<span class="from-chip from-chip-self">自分で書いた</span>`}
      </div>
    </div>
  `;
}

/** 「進行中の道として公開する」CTA */
function renderPlanApplyCTA() {
  const r = checkReadiness();
  const ready = r.all_met;

  if (ready) {
    return html`
      <div class="plan-apply-block plan-apply-ready">
        <div class="plan-apply-stamp">SHINKOCHU 申請可能</div>
        <div class="plan-apply-title">後輩に渡す道として<br>公開できる状態です</div>
        <a class="plan-apply-cta" href="#/apply">▶ 進行中の道として公開する</a>
      </div>
    `;
  }

  // 未達のときも、達成状況に応じてメッセージを出す
  if (Store.userPlan.cards.length === 0) {
    return ''; // 空の状態は empty 画面で対応済み
  }

  return html`
    <div class="plan-apply-block plan-apply-locked">
      <div class="plan-apply-locked-title">公開まで あと ${r.total_conditions - r.conditions_met} つ</div>
      <div class="plan-apply-locked-sub">${r.next_actions.length > 0 ? esc(r.next_actions.join(' ・ ')) : ''}</div>
    </div>
  `;
}

/* ========== レーンバー計算 ========== */

/** ある era をまたぐ／含むカードを抽出して、レーンバー情報を返す */
function computeLanesForEra(era, allCards) {
  // 1ヶ月以上の duration のカードのみレーンに描く
  const eraIdx = ERA_ORDER.indexOf(era);
  if (eraIdx < 0) return [];

  const lanes = [];

  allCards.forEach(card => {
    const cardEra = STAGE_TO_ERA[card.when?.stage] || 'unknown';
    if (cardEra !== era) return; // この era で開始するカードのみ対象

    // 期間文字列をパース
    const months = parseDurationMonths(card.when?.duration);
    if (months < 1.5) return; // 短期は描かない

    // バーの長さ（ピクセル）：ざっくり 1学期 = 80px と仮定
    const heightPx = Math.min(months * 40, 240);

    lanes.push({
      cardId: card.id,
      color: getCategoryColor(card.category),
      top: 24,
      height: heightPx,
    });
  });

  return lanes;
}

/** "2週間" "3ヶ月" "12ヶ月" "進行中" などを月数に変換 */
function parseDurationMonths(s) {
  if (!s) return 0;
  if (s.includes('進行中')) return 6;
  const wkMatch = s.match(/(\d+)\s*週/);
  if (wkMatch) return parseInt(wkMatch[1], 10) / 4;
  const mMatch = s.match(/(\d+)\s*ヶ?月/);
  if (mMatch) return parseInt(mMatch[1], 10);
  const yMatch = s.match(/(\d+)\s*年/);
  if (yMatch) return parseInt(yMatch[1], 10) * 12;
  return 0;
}

/** カテゴリ → 色 */
function getCategoryColor(cat) {
  const map = {
    academic: '#1d3557',
    career: '#d63a2f',
    network: '#ffd60a',
    skill: '#6f8a5e',
    global: '#161616',
  };
  return map[cat] || '#6f8a5e';
}

/* ========== 衝突検出 ========== */

/** 計画内の衝突を検出して返す（同じ era に2つ以上のカードがある場合） */
function detectConflicts(cards) {
  const byEra = {};
  cards.forEach(c => {
    const era = STAGE_TO_ERA[c.when?.stage] || 'unknown';
    const months = parseDurationMonths(c.when?.duration);
    // 海外カテゴリは期間によらず衝突候補（物理的に不在）
    // それ以外は1ヶ月以上のものが対象
    if (c.category !== 'global' && months < 1) return;
    if (!byEra[era]) byEra[era] = [];
    byEra[era].push(c);
  });

  const conflicts = [];
  Object.entries(byEra).forEach(([era, eraCards]) => {
    if (eraCards.length < 2) return;
    conflicts.push({
      key: `${era}:${eraCards.map(c => c.id).sort().join(',')}`,
      eraLabel: ERA_LABEL[era] || era,
      cards: eraCards,
    });
  });

  return conflicts;
}

/* ========== カード編集シート ========== */

/** カードタップ時：アクションシートを開く */
window.openPlanCardSheet = function(cardId) {
  const card = Store.userPlan.cards.find(c => c.id === cardId);
  if (!card) return;
  showPlanCardSheet(card);
};

function showPlanCardSheet(card) {
  // モーダル用の sheet 要素を動的に作成
  const overlay = document.createElement('div');
  overlay.className = 'sheet-overlay';
  overlay.onclick = (e) => {
    if (e.target === overlay) closePlanSheet();
  };

  const sheet = document.createElement('div');
  sheet.className = 'sheet-container';
  sheet.innerHTML = renderPlanCardSheet(card);

  overlay.appendChild(sheet);
  document.body.appendChild(overlay);

  // フォーム送信用のグローバル保持
  window._currentSheetCardId = card.id;
}

function renderPlanCardSheet(card) {
  const stageLbl = stageLabel(card.when?.stage) || '';
  const duration = card.when?.duration || '';
  const isPlanned = card.state === 'planned';

  return html`
    <div class="modal-grab"></div>

    <div class="plan-sheet-head">
      <div class="plan-sheet-head-text">
        <div class="plan-sheet-label">CARD / ${esc(stageLbl)}</div>
        <div class="plan-sheet-title">${esc(card.what)}</div>
      </div>
      <button class="remix-close" onclick="closePlanSheet()" aria-label="閉じる">✕</button>
    </div>

    <div class="plan-sheet-body">
      ${card.why ? html`
        <div class="plan-sheet-section">
          <div class="plan-sheet-section-label">NAZE / なぜ</div>
          <div class="plan-sheet-why-text">${esc(card.why)}</div>
        </div>
      ` : ''}

      ${card.result?.goal ? html`
        <div class="plan-sheet-section">
          <div class="plan-sheet-section-label">MOKUHYOU / 目標</div>
          <div class="plan-sheet-goal-text">${esc(card.result.goal)}</div>
        </div>
      ` : ''}

      <div class="plan-sheet-section">
        <div class="plan-sheet-section-label">FURIKAERI / ふりかえり</div>
        ${card.result?.reflection ? html`
          <div class="plan-sheet-reflection-text">${esc(card.result.reflection)}</div>
        ` : html`
          <div class="plan-sheet-empty-text">まだ書かれていません</div>
        `}
      </div>

      ${card.parent_handle ? html`
        <div class="plan-sheet-section">
          <span class="from-chip">${esc(card.parent_handle)}をアレンジ</span>
        </div>
      ` : ''}
    </div>

    <div class="plan-sheet-actions">
      ${isPlanned
        ? html`<button class="plan-sheet-btn plan-sheet-btn-primary" onclick="openReflectionEditor('${esc(card.id)}')">ふりかえりを書く</button>`
        : html`<button class="plan-sheet-btn plan-sheet-btn-primary" onclick="openReflectionEditor('${esc(card.id)}')">ふりかえりを編集</button>`}
      <button class="plan-sheet-btn" onclick="confirmDeleteCard('${esc(card.id)}')">削除</button>
      <button class="plan-sheet-btn" onclick="closePlanSheet()">閉じる</button>
    </div>
  `;
}

window.closePlanSheet = function() {
  const overlay = document.querySelector('.sheet-overlay');
  if (overlay) overlay.remove();
  window._currentSheetCardId = null;
};

/* ========== ふりかえり編集 ========== */

window.openReflectionEditor = function(cardId) {
  const card = Store.userPlan.cards.find(c => c.id === cardId);
  if (!card) return;

  const sheet = document.querySelector('.sheet-container');
  if (!sheet) return;

  sheet.innerHTML = html`
    <div class="modal-grab"></div>

    <div class="plan-sheet-head">
      <div class="plan-sheet-head-text">
        <div class="plan-sheet-label">FURIKAERI / ふりかえり</div>
        <div class="plan-sheet-title">${esc(card.what)}</div>
      </div>
      <button class="remix-close" onclick="closePlanSheet()" aria-label="閉じる">✕</button>
    </div>

    <div class="plan-sheet-body">
      ${card.result?.goal ? html`
        <div class="plan-reflection-context">
          <div class="plan-reflection-context-label">目標</div>
          <div class="plan-reflection-context-text">${esc(card.result.goal)}</div>
        </div>
      ` : ''}

      <div class="plan-reflection-arrow">↓</div>

      <textarea id="reflection-textarea" class="plan-reflection-input" placeholder="実際にやってみてどうだったか。良かったところも、思ってたのと違ったところも、正直に。">${esc(card.result?.reflection || '')}</textarea>

      <div class="plan-reflection-hint">
        後輩にとっては、正直なふりかえりこそ一番の参考になります。
      </div>
    </div>

    <div class="plan-sheet-actions">
      <button class="plan-sheet-btn plan-sheet-btn-primary" onclick="saveReflection('${esc(cardId)}')">保存して完了にする</button>
      <button class="plan-sheet-btn" onclick="closePlanSheet()">キャンセル</button>
    </div>
  `;
};

window.saveReflection = function(cardId) {
  const textarea = document.getElementById('reflection-textarea');
  if (!textarea) return;
  const value = textarea.value.trim();

  const card = Store.userPlan.cards.find(c => c.id === cardId);
  if (!card) return;

  // result.reflection を更新、state を reflected に
  card.result = card.result || {};
  card.result.reflection = value;
  if (value.length > 0) {
    card.state = 'reflected';
  }
  saveUserPlan();
  closePlanSheet();
  showToast(value.length > 0 ? 'ふりかえりを保存しました' : '保存しました', 'success');
  handleRouteChange();
};

window.confirmDeleteCard = function(cardId) {
  if (!confirm('このカードを削除しますか？元に戻せません。')) return;
  removeCardFromPlan(cardId);
  closePlanSheet();
  showToast('カードを削除しました');
  handleRouteChange();
};

/* ========== 衝突詳細シート ========== */

window.openConflictSheet = function(conflictKey) {
  // conflictKey の形式: "era:cardId1,cardId2,..."
  const [eraId, idsStr] = conflictKey.split(':');
  const ids = idsStr.split(',');
  const cards = Store.userPlan.cards.filter(c => ids.includes(c.id));
  const eraLabel = ERA_LABEL[eraId] || eraId;

  // 同じカテゴリ同士か別カテゴリ同士か判定
  const categories = new Set(cards.map(c => c.category));
  const sameCategory = categories.size === 1;

  // 海外を含むか
  const hasGlobal = cards.some(c => c.category === 'global');

  showConflictSheet({
    key: conflictKey,
    eraLabel,
    cards,
    sameCategory,
    hasGlobal,
  });
};

function showConflictSheet(conflict) {
  const overlay = document.createElement('div');
  overlay.className = 'sheet-overlay';
  overlay.onclick = (e) => {
    if (e.target === overlay) closePlanSheet();
  };

  const sheet = document.createElement('div');
  sheet.className = 'sheet-container';
  sheet.innerHTML = renderConflictSheet(conflict);

  overlay.appendChild(sheet);
  document.body.appendChild(overlay);
}

function renderConflictSheet(conflict) {
  const { eraLabel, cards, sameCategory, hasGlobal, key } = conflict;

  // ハードコンフリクト（海外含む）の場合はメリットを出さない
  if (hasGlobal) {
    return renderHardConflictSheet(conflict);
  }

  // メリット・デメリットの文言（カテゴリペアに応じて出し分け可能、いまは汎用）
  const pros = sameCategory ? [
    '同じ方向で深まる',
    '集中投下で短期で結果が出る',
    '一貫した道筋として残せる',
  ] : [
    '相乗効果 — 一方が他方を加速',
    '時間の密度が上がる',
    '出会いが両方で効く',
    '「両立した」が capacity の証拠に',
  ];

  const cons = sameCategory ? [
    '同じエネルギーを奪い合う',
    '同質的になりすぎる',
    'バランスが偏る',
  ] : [
    '二兎で両方が中途半端に',
    '容量オーバー・燃え尽き',
    '余白が消える',
    '消耗でふりかえりが浅く',
  ];

  return html`
    <div class="modal-grab"></div>

    <div class="plan-sheet-head">
      <div class="plan-sheet-head-text">
        <div class="plan-sheet-label">OVERLAP / 重なり</div>
        <div class="plan-sheet-title">活動の重なり</div>
        <div class="conflict-sub">${esc(eraLabel)} ・ ${cards.length}つの活動が並行します</div>
      </div>
      <button class="remix-close" onclick="closePlanSheet()" aria-label="閉じる">✕</button>
    </div>

    <div class="plan-sheet-body">

      <div class="conflict-cards-row">
        ${cards.map((c, i) => html`
          ${i > 0 ? html`<span class="conflict-plus">＋</span>` : ''}
          <div class="conflict-card-mini">
            <div class="card-stripe stripe-${esc(c.category || 'skill')}" style="width:4px;"></div>
            <div class="conflict-card-mini-body">
              <div class="conflict-card-mini-cat">${esc(CATEGORY_LABEL[c.category] || c.category)}</div>
              <div class="conflict-card-mini-what">${esc(c.what)}</div>
            </div>
          </div>
        `).join('')}
      </div>

      <div class="conflict-judge ${sameCategory ? 'conflict-judge-same' : 'conflict-judge-diff'}">
        <span class="conflict-judge-icon">${sameCategory ? '⚡' : 'ⓘ'}</span>
        <span class="conflict-judge-text">
          ${sameCategory
            ? '同じカテゴリの重なりです。同じエネルギーを奪い合いやすい組み合わせ。'
            : '違うカテゴリの重なりです。使うエネルギーがぶつかりにくく、相乗しやすい組み合わせ。'}
          どうするかはあなた次第です。
        </span>
      </div>

      <div class="conflict-pros-cons">
        <div class="conflict-column">
          <div class="conflict-column-head conflict-column-pros">↗ メリット</div>
          <div class="conflict-column-body">
            ${pros.map(p => html`<div class="conflict-item">●&nbsp;${esc(p)}</div>`).join('')}
          </div>
        </div>
        <div class="conflict-column">
          <div class="conflict-column-head conflict-column-cons">↘ デメリット</div>
          <div class="conflict-column-body">
            ${cons.map(c => html`<div class="conflict-item">●&nbsp;${esc(c)}</div>`).join('')}
          </div>
        </div>
      </div>

      ${renderConflictTestimony(cards)}

    </div>

    <div class="plan-sheet-actions plan-sheet-actions-conflict">
      <div class="conflict-actions-label">どうしますか</div>
      <button class="conflict-action-btn conflict-action-accept" onclick="acceptOverlap('${esc(key)}')">
        <span class="conflict-action-icon">○</span>
        <div class="conflict-action-text">
          <div class="conflict-action-title">このまま重ねる</div>
          <div class="conflict-action-sub">意図的な選択として記録・以後通知しない</div>
        </div>
      </button>
      <button class="conflict-action-btn" onclick="closePlanSheet()">
        <span class="conflict-action-icon">▤</span>
        <div class="conflict-action-text">
          <div class="conflict-action-title">あとで考える</div>
          <div class="conflict-action-sub">カードを編集する場合はカードをタップ</div>
        </div>
      </button>
    </div>
  `;
}

function renderHardConflictSheet(conflict) {
  const { eraLabel, cards, key } = conflict;
  return html`
    <div class="modal-grab"></div>

    <div class="plan-sheet-head">
      <div class="plan-sheet-head-text">
        <div class="plan-sheet-label">HARD CONFLICT / 衝突</div>
        <div class="plan-sheet-title">物理的に重ねられません</div>
        <div class="conflict-sub">${esc(eraLabel)} ・ 海外滞在中は他の活動と並行できません</div>
      </div>
      <button class="remix-close" onclick="closePlanSheet()" aria-label="閉じる">✕</button>
    </div>

    <div class="plan-sheet-body">
      <div class="conflict-cards-row">
        ${cards.map((c, i) => html`
          ${i > 0 ? html`<span class="conflict-plus">＋</span>` : ''}
          <div class="conflict-card-mini">
            <div class="card-stripe stripe-${esc(c.category || 'skill')}" style="width:4px;"></div>
            <div class="conflict-card-mini-body">
              <div class="conflict-card-mini-cat">${esc(CATEGORY_LABEL[c.category] || c.category)}</div>
              <div class="conflict-card-mini-what">${esc(c.what)}</div>
            </div>
          </div>
        `).join('')}
      </div>

      <div class="conflict-judge conflict-judge-hard">
        <span class="conflict-judge-icon">⚠</span>
        <span class="conflict-judge-text">
          この期間は物理的に不在になります。どちらかを別の学期へ動かす必要があります。
        </span>
      </div>
    </div>

    <div class="plan-sheet-actions plan-sheet-actions-conflict">
      <div class="conflict-actions-label">どちらかを動かす</div>
      ${cards.map(c => html`
        <button class="conflict-action-btn" onclick="openPlanCardSheet('${esc(c.id)}')">
          <span class="conflict-action-icon">↔</span>
          <div class="conflict-action-text">
            <div class="conflict-action-title">「${esc(truncate(c.what, 20))}」を動かす</div>
            <div class="conflict-action-sub">タップしてカードを編集</div>
          </div>
        </button>
      `).join('')}
    </div>
  `;
}

function renderConflictTestimony(cards) {
  // 同じような重なりをした先輩を探す
  const eras = new Set();
  cards.forEach(c => eras.add(STAGE_TO_ERA[c.when?.stage]));
  const categoriesInConflict = new Set(cards.map(c => c.category));

  // モデルの中で同様の重なりがあるカード群を探す
  for (const model of Store.models) {
    if (!model.cards || model.cards.length < 2) continue;
    const candidates = model.cards.filter(c => {
      const era = STAGE_TO_ERA[c.when?.stage];
      return eras.has(era) && c.state === 'reflected' && c.result?.reflection;
    });
    if (candidates.length >= 2) {
      // この先輩の証言を表示
      const card = candidates[0];
      return html`
        <div class="conflict-testimony">
          <div class="conflict-testimony-head">
            <span class="conflict-testimony-quote">"</span>
            同じ重なりをした先輩
          </div>
          <div class="conflict-testimony-line">
            ${esc(model.handle.toUpperCase())} も同じ時期に2つの活動を並行。
          </div>
          <div class="conflict-testimony-card">
            <div class="conflict-testimony-row"><span class="conflict-testimony-key">目標</span>${esc(card.result.goal || '')}</div>
            <div class="conflict-testimony-row"><span class="conflict-testimony-key">ふり</span>${esc(card.result.reflection)}</div>
          </div>
        </div>
      `;
    }
  }
  return '';
}

window.acceptOverlap = function(key) {
  if (!Store.userPlan.intentional_overlaps) Store.userPlan.intentional_overlaps = [];
  if (!Store.userPlan.intentional_overlaps.some(o => o.key === key)) {
    Store.userPlan.intentional_overlaps.push({
      key,
      accepted_at: new Date().toISOString(),
    });
    saveUserPlan();
  }
  closePlanSheet();
  showToast('意図的な選択として記録しました', 'success');
  handleRouteChange();
};

/** イベントハンドラの後付け（onchange など） */
function attachPlanEventHandlers() {
  // 現状特に動的紐づけが必要なものはない（onclick で完結）
}

function renderOrgs() {
  const body = document.getElementById('orgs-body');
  body.innerHTML = renderOrgsContent();
}

function renderOrgsContent() {
  if (Store.orgs.length === 0) {
    return html`
      <div class="orgs-empty">
        <div class="orgs-empty-icon">◈</div>
        <div class="orgs-empty-title">まだ団体は登録されていません</div>
        <div class="orgs-empty-body">
          サークル、ゼミ、インターン先、研究室など、所属している場所をモデルが申請するとここに並びます。
        </div>
      </div>
    `;
  }

  // 募集中の団体と、そうでない団体に分ける
  const recruiting = Store.orgs.filter(o => o.recruit?.active);
  const others = Store.orgs.filter(o => !o.recruit?.active);

  return html`
    <div class="orgs-intro">
      <div class="orgs-intro-label">DANTAI / 団体</div>
      <div class="orgs-intro-title">場所から探す</div>
      <div class="orgs-intro-body">サークル・ゼミ・インターン先など、人が集まって何かをしている場所。各団体に所属するモデルのカードが集まっています。</div>
    </div>

    ${recruiting.length > 0 ? html`
      <div class="sec-head">
        <div class="sec-title"><span class="sec-stamp">募集中</span></div>
        <div class="sec-meta">RECRUIT / ${recruiting.length}</div>
      </div>
      ${recruiting.map(o => renderOrgsListCard(o, true)).join('')}
    ` : ''}

    ${others.length > 0 ? html`
      <div class="sec-head">
        <div class="sec-title"><span class="sec-stamp">団体一覧</span></div>
        <div class="sec-meta">ALL / ${others.length}</div>
      </div>
      ${others.map(o => renderOrgsListCard(o, false)).join('')}
    ` : ''}
  `;
}

function renderOrgsListCard(org, isRecruiting) {
  const activeCount = Store.models.filter(m => m.status === 'shinkochu' && (m.orgs || []).includes(org.id)).length;
  const alumniCount = Store.models.filter(m => m.status === 'sotsugyo' && (m.orgs || []).includes(org.id)).length;
  const cardCount = countOrgCards(org.id);

  return html`
    <a class="orgs-list-card" href="${orgUrl(org.id)}">
      <div class="orgs-list-card-row">
        ${renderOrgEmblem(org, 'emblem-md')}
        <div class="orgs-list-card-text">
          <div class="orgs-list-card-meta">
            <span class="pill pill-sage" style="font-size:9px;">${esc(org.type_label || 'DANTAI')}</span>
            ${isRecruiting ? html`<span class="pill pill-vermilion" style="font-size:9px;">★ 募集中</span>` : ''}
          </div>
          <div class="orgs-list-card-name">${esc(org.name)}</div>
          <div class="orgs-list-card-tagline">${esc(org.tagline)}</div>
        </div>
      </div>
      <div class="orgs-list-card-stats">
        <div class="orgs-list-card-stat"><span class="orgs-list-stat-num">${activeCount}</span> ACTIVE</div>
        <div class="orgs-list-card-stat"><span class="orgs-list-stat-num">${alumniCount}</span> ALUMNI</div>
        <div class="orgs-list-card-stat"><span class="orgs-list-stat-num">${cardCount}</span> CARDS</div>
      </div>
    </a>
  `;
}

/** 団体内のカード総数（所属モデルのカードを集約） */
function countOrgCards(orgId) {
  let total = 0;
  Store.models.forEach(m => {
    if ((m.orgs || []).includes(orgId)) {
      total += (m.cards || []).length;
    }
  });
  return total;
}

/* ========== 団体詳細ページ ========== */

function renderOrg(orgId) {
  const org = getOrg(orgId);
  const body = document.getElementById('org-body');
  if (!org) {
    body.innerHTML = html`
      <div class="model-not-found">
        <div class="model-not-found-title">団体が見つかりませんでした</div>
        <a class="btn btn-primary mt-3" href="#/orgs">団体一覧へ</a>
      </div>
    `;
    return;
  }
  body.innerHTML = renderOrgContent(org);
}

function renderOrgContent(org) {
  return [
    renderOrgHero(org),
    renderOrgRecruit(org),
    renderOrgActiveMembers(org),
    renderOrgAlumniMembers(org),
    renderOrgActivityFeed(org),
  ].join('');
}

/** ヒーロー：エンブレム + 名前 + メトリクス */
function renderOrgHero(org) {
  const activeMembers = Store.models.filter(m => m.status === 'shinkochu' && (m.orgs || []).includes(org.id));
  const alumniMembers = Store.models.filter(m => m.status === 'sotsugyo' && (m.orgs || []).includes(org.id));
  const totalCards = countOrgCards(org.id);

  return html`
    <div class="org-hero">
      <div class="org-hero-stamp">DANTAI / 団体</div>
      <div class="org-hero-row">
        ${renderOrgEmblem(org, 'emblem-lg')}
        <div class="org-hero-text">
          <div class="org-hero-tags">
            <span class="pill pill-sage" style="font-size:9px;">${esc(org.type_label || 'DANTAI')}</span>
            ${org.campus ? html`<span class="pill pill-yellow-pale" style="font-size:9px;">${esc(org.campus)}</span>` : ''}
            ${org.founded ? html`<span class="pill pill-paper" style="font-size:9px;">SINCE ${esc(org.founded)}</span>` : ''}
          </div>
          <div class="org-hero-name">${esc(org.name)}</div>
          <div class="org-hero-tagline">${esc(org.tagline)}</div>
        </div>
      </div>
      ${org.about ? html`
        <div class="org-hero-about">${esc(org.about)}</div>
      ` : ''}
      <div class="org-hero-stats">
        <div class="org-hero-stat">
          <div class="org-hero-stat-num">${activeMembers.length}</div>
          <div class="org-hero-stat-label">ACTIVE</div>
        </div>
        <div class="org-hero-stat">
          <div class="org-hero-stat-num">${alumniMembers.length}</div>
          <div class="org-hero-stat-label">ALUMNI</div>
        </div>
        <div class="org-hero-stat">
          <div class="org-hero-stat-num">${totalCards}</div>
          <div class="org-hero-stat-label">CARDS</div>
        </div>
      </div>
    </div>
  `;
}

/** 募集中ブロック */
function renderOrgRecruit(org) {
  const recruit = org.recruit;
  if (!recruit?.active) return '';

  return html`
    <div class="org-recruit">
      <div class="org-recruit-head">RECRUIT / 募集中</div>
      <div class="org-recruit-title">${esc(recruit.title)}</div>
      <div class="org-recruit-body">${esc(recruit.body)}</div>
      ${recruit.tags?.length > 0 ? html`
        <div class="org-recruit-tags">
          ${recruit.tags.map(t => html`<span class="org-recruit-tag">${esc(t)}</span>`).join('')}
        </div>
      ` : ''}
      ${recruit.cta_label ? html`
        <button class="org-recruit-cta" onclick="handleOrgRecruitClick('${esc(org.id)}')">${esc(recruit.cta_label)}</button>
      ` : ''}
    </div>
  `;
}

/** 現役メンバー */
function renderOrgActiveMembers(org) {
  const members = Store.models.filter(m => m.status === 'shinkochu' && (m.orgs || []).includes(org.id));
  if (members.length === 0) {
    return html`
      <div class="sec-head">
        <div class="sec-title"><span class="sec-stamp" style="background:var(--sage);">現役</span></div>
        <div class="sec-meta">ACTIVE / 0</div>
      </div>
      <div class="org-members-empty">まだ現役メンバーがいません</div>
    `;
  }

  return html`
    <div class="sec-head">
      <div class="sec-title"><span class="sec-stamp" style="background:var(--sage);">現役</span></div>
      <div class="sec-meta">ACTIVE / ${members.length}</div>
    </div>
    <div class="org-members-grid">
      ${members.map(m => renderOrgMemberCard(m, 'active')).join('')}
    </div>
  `;
}

/** 卒業生メンバー */
function renderOrgAlumniMembers(org) {
  const members = Store.models.filter(m => m.status === 'sotsugyo' && (m.orgs || []).includes(org.id));
  if (members.length === 0) return '';

  return html`
    <div class="sec-head">
      <div class="sec-title"><span class="sec-stamp" style="background:var(--blue);">卒業生</span></div>
      <div class="sec-meta">ALUMNI / ${members.length}</div>
    </div>
    <div class="org-members-grid">
      ${members.map(m => renderOrgMemberCard(m, 'alumni')).join('')}
    </div>
  `;
}

function renderOrgMemberCard(model, variant) {
  const yearLabel = getYearLabel(model);
  const keitouLabel = (model.keitou || []).map(k => getKeitou(k)?.label_en).filter(Boolean).join(' × ');

  return html`
    <a class="org-member-card" href="${modelUrl(model.id)}">
      <div class="org-member-id">
        ${renderAvatar(model, 'sm')}
        <div class="org-member-name-block">
          <div class="org-member-handle">${esc(model.handle.toUpperCase())}</div>
          <div class="org-member-name">${esc(model.display_name)}${variant === 'alumni' && model.graduation_year ? `（${model.graduation_year}卒）` : ''}</div>
        </div>
      </div>
      <div class="org-member-sub">${esc(model.subtitle)} ／ ${esc(yearLabel)}</div>
      ${keitouLabel ? html`<span class="pill ${variant === 'alumni' ? 'pill-blue' : 'pill-sage'}" style="font-size:9px;">${esc(keitouLabel)}</span>` : ''}
    </a>
  `;
}

/** 団体で起きてきたこと：所属モデルのカードを集約 */
function renderOrgActivityFeed(org) {
  // 所属モデルのカードを集める（reflected優先、planned後ろ）
  const allCards = [];
  Store.models.forEach(m => {
    if (!(m.orgs || []).includes(org.id)) return;
    (m.cards || []).forEach(c => {
      allCards.push({
        card: c,
        model: m,
        sortKey: c.state === 'reflected' ? 1 : 2,
      });
    });
  });

  // カードがあるものだけ、最大10件
  const filtered = allCards.filter(({ card }) => card.org === org.id || true).slice(0, 12);

  if (filtered.length === 0) {
    return html`
      <div class="sec-head">
        <div class="sec-title">団体で起きてきたこと</div>
        <div class="sec-meta">ACTIVITY</div>
      </div>
      <div class="org-activity-empty">所属モデルのカードがまだありません</div>
    `;
  }

  return html`
    <div class="sec-head">
      <div class="sec-title">団体で起きてきたこと</div>
      <div class="sec-meta">ACTIVITY / ${filtered.length}</div>
    </div>
    <div class="org-activity-intro">所属モデルのカードから自動で集まる</div>
    <div class="org-activity-list">
      ${filtered.map(({ card, model }) => renderOrgActivityCard(card, model)).join('')}
    </div>
  `;
}

function renderOrgActivityCard(card, model) {
  const stageLbl = stageLabel(card.when?.stage) || '';
  const isPlanned = card.state === 'planned';
  // 卒業した先輩のカードは年も含めて表示できる
  const yearTag = inferActivityYear(card, model);

  return html`
    <a class="org-activity-card" href="${modelUrl(model.id)}">
      <div class="card-stripe stripe-${esc(card.category || 'skill')}"></div>
      <div class="org-activity-card-body">
        <div class="org-activity-card-when">
          <span class="when-pill">${esc(stageLbl)}</span>
          ${yearTag ? html`<span class="org-activity-card-year">${esc(yearTag)}</span>` : ''}
          ${isPlanned ? html`<span class="plan-state-pill plan-state-planned">予定</span>` : ''}
        </div>
        <div class="org-activity-card-what">${esc(card.what)}</div>
        <div class="org-activity-card-by">
          — <span class="org-activity-card-handle">${esc(model.handle.toUpperCase())}</span> のカードより
        </div>
      </div>
    </a>
  `;
}

/** カードの年を推定（卒業生のカードのみ年代を出す） */
function inferActivityYear(card, model) {
  if (model.status !== 'sotsugyo' || !model.graduation_year) return '';
  // 簡易：卒業年から逆算
  const era = STAGE_TO_ERA[card.when?.stage];
  const yearMap = {
    daigaku_1: model.graduation_year - 3,
    daigaku_2: model.graduation_year - 2,
    daigaku_3: model.graduation_year - 1,
    daigaku_4: model.graduation_year,
  };
  const y = yearMap[era];
  return y ? String(y) : '';
}

/** 募集 CTA クリック時 */
window.handleOrgRecruitClick = function(orgId) {
  const org = getOrg(orgId);
  if (org?.recruit?.cta_url && org.recruit.cta_url !== '#') {
    window.open(org.recruit.cta_url, '_blank');
  } else {
    showToast(`${org?.name || ''}の新歓ページは近日公開`);
  }
};

function renderModel(modelId) {
  const model = getModel(modelId);
  const body = document.getElementById('model-body');
  if (!model) {
    body.innerHTML = html`
      <div class="model-not-found">
        <div class="model-not-found-title">モデルが見つかりませんでした</div>
        <a class="btn btn-primary mt-3" href="#/home">ホームに戻る</a>
      </div>
    `;
    return;
  }
  body.innerHTML = renderModelContent(model);
  recordRecentModel(modelId);
}

/** モデル詳細ページの全体を組み立てる */
function renderModelContent(model) {
  return [
    renderModelHero(model),
    renderModelJourney(model),
  ].join('');
}

/** ヒーロー：キャラ画像のビジュアルヒーロー＋コンパクトなメタ情報 */
function renderModelHero(model) {
  const design = getModelDesign(model);
  const lightBg = isLightColor(design.personalColor);
  const yearLabel = getYearLabel(model);

  // 系統＋団体のタグ（1行に集約）
  const keitouTags = (model.keitou || []).map(kid => {
    const k = getKeitou(kid);
    return k ? html`<span class="pill pill-sage-pale">${esc(k.label_en)}</span>` : '';
  }).join('');

  const orgTags = (model.orgs || []).map(oid => {
    const o = getOrg(oid);
    return o ? html`<span class="pill pill-yellow-pale">${esc(shortenOrgName(o.name))}</span>` : '';
  }).join('');

  // bio を改行で分割して<br>に変換
  const bioHtml = (model.bio || '').split('\n').map(line => esc(line)).join('<br>');

  return html`
    <div class="model-vhero ${lightBg ? 'model-vhero--light' : ''}"
         style="--personal-color:${design.personalColor}; --accent-color:${design.accentColor};">
      ${model.character_image
        ? html`<div class="model-vhero-art">${renderCharacterImage(model.character_image)}</div>`
        : ''}
      <div class="model-vhero-grad"></div>
      <div class="model-vhero-status">${renderStatusPill(model.status, true)}</div>
      <div class="model-vhero-id">
        <div class="model-vhero-handle">${esc(model.handle.toUpperCase())}</div>
        <div class="model-vhero-name">${esc(model.display_name)}</div>
        <div class="model-vhero-subtitle">${esc(model.subtitle)}</div>
      </div>
    </div>

    <div class="model-meta-row">
      ${keitouTags}
      ${orgTags}
      ${yearLabel ? html`<span class="pill pill-plain">${esc(yearLabel)}</span>` : ''}
    </div>

    ${model.bio ? html`<div class="model-bio model-bio-slim">${bioHtml}</div>` : ''}

    ${renderModelCollab(model)}
  `;
}

/** コラボ受付窓（コンパクトな1行バンド） */
function renderModelCollab(model) {
  const collab = model.collab;
  if (!collab) return '';

  const openLabels = (collab.open || []).map(k => COLLAB_LABEL[k] || k);
  if (openLabels.length === 0) return '';

  return html`
    <div class="model-collab-band">
      <div class="model-collab-band-info">
        <span class="model-collab-band-label">COLLAB</span>
        <span class="model-collab-band-items">${openLabels.map(esc).join(' ・ ')} OK</span>
      </div>
      <button class="model-collab-band-btn" onclick="handleCollabMessage('${esc(model.id)}')">▷ メッセージ</button>
    </div>
  `;
}

/** 人生journey：時代ごとにカードをグループ分けして表示 */
function renderModelJourney(model) {
  const cards = model.cards || [];

  // カードを era（学年単位）ごとにグループ化
  const byEra = {};
  cards.forEach(card => {
    const stage = card.when?.stage;
    if (!stage) return;
    const era = STAGE_TO_ERA[stage] || 'unknown';
    if (!byEra[era]) byEra[era] = [];
    byEra[era].push(card);
  });

  // 表示順序
  const eras = ERA_ORDER.filter(e => byEra[e]?.length > 0);

  // 未来の時代（プレースホルダー）：現在の学年より後
  const futureEra = getFutureEra(model);

  return html`
    <div class="model-journey-head">
      <div class="model-journey-title">人生journey</div>
      <div class="model-journey-meta">CARDS / ${cards.length}</div>
    </div>

    ${eras.map(era => renderModelEra(era, byEra[era], model)).join('')}

    ${futureEra ? renderModelFutureEra(futureEra, model) : ''}
  `;
}

/** 時代1つ分のレンダリング（era-bar ＋ カード群） */
function renderModelEra(era, eraCards, model) {
  // 「高校以前」と「高校時代」は折りたたみ表示
  const isPreCollege = era === 'pre' || era === 'kokou';

  if (isPreCollege) {
    return html`
      <details class="model-era-collapsed">
        <summary>
          <span>${esc(ERA_LABEL[era])}</span>
          <span class="model-era-collapsed-meta">カード ${eraCards.length} 枚 ・ タップで展開</span>
          <span class="model-era-collapsed-icon">＋</span>
        </summary>
        <div class="model-era-body">
          ${eraCards.map(c => renderModelCard(c, model)).join('')}
        </div>
      </details>
    `;
  }

  // 大学・社会人は展開済み
  const eraNum = getEraNumber(era);
  return html`
    <div class="model-era">
      <div class="model-era-bar">
        <span class="model-era-num">${esc(eraNum)}</span>
        <span class="model-era-name">${esc(getEraEnLabel(era))} / ${esc(ERA_LABEL[era])}</span>
        <span class="model-era-count">${eraCards.length}</span>
      </div>
      <div class="model-era-body">
        ${eraCards.map(c => renderModelCard(c, model)).join('')}
      </div>
    </div>
  `;
}

/** カード1枚のレンダリング（モデル詳細用：アコーディオン。進行中だけ自動展開） */
function renderModelCard(card, model) {
  const stageLbl = stageLabel(card.when?.stage) || '';
  const duration = card.when?.duration || '';
  const isInProgress = card.state === 'planned' && (duration === '進行中' || duration.includes('進行'));

  return html`
    <details class="model-card-acc ${isInProgress ? 'model-card-in-progress' : ''}" ${isInProgress ? 'open' : ''}>
      <summary class="model-card-acc-head">
        <span class="card-stripe stripe-${esc(card.category || 'skill')}"></span>
        <span class="model-card-acc-meta">
          <span class="when-pill">${esc(stageLbl)}</span>
          ${isInProgress ? html`<span class="model-in-progress-tag">SHINKOCHU</span>` : ''}
        </span>
        <span class="model-card-acc-what">${esc(card.what)}</span>
        <span class="model-card-acc-icon" aria-hidden="true"></span>
      </summary>
      <div class="model-card-acc-body">
        ${duration ? html`<div class="model-card-acc-duration">期間 / ${esc(duration)}</div>` : ''}
        ${card.why ? html`
          <div class="why-box">
            <div class="why-label">NAZE / なぜ</div>
            <div class="why-text">${esc(card.why)}</div>
          </div>
        ` : ''}
        ${renderCardResult(card)}
        ${renderCardSaveControls(card, model)}
      </div>
    </details>
  `;
}

/** カードの目標/ふりかえりブロック */
function renderCardResult(card) {
  const goal = card.result?.goal;
  const reflection = card.result?.reflection;
  if (!goal && !reflection) return '';

  return html`
    <div class="result-block">
      ${goal ? html`<div class="res-row"><span class="res-key">目標</span><span class="res-val">${esc(goal)}</span></div>` : ''}
      ${reflection
        ? html`<div class="res-row"><span class="res-key">ふり</span><span class="res-val">${esc(reflection)}</span></div>`
        : (card.state === 'planned'
            ? html`<div class="res-row"><span class="res-key">ふり</span><span class="res-val res-val-empty">まだ書かれていません</span></div>`
            : '')}
    </div>
  `;
}

/** 保存ボタン＋いいねボタン */
function renderCardSaveControls(card, model) {
  const saved = isCardSaved(model.id, card.id);
  const liked = isCardLiked(model.id, card.id);

  return html`
    <div class="model-card-actions">
      <button class="model-save-btn ${saved ? 'model-save-btn-saved' : ''}"
              onclick="handleSaveCard('${esc(model.id)}', '${esc(card.id)}')">
        ${saved ? '保存済み' : '＋ このカードを残す'}
      </button>
      <button class="model-like-btn ${liked ? 'model-like-btn-liked' : ''}"
              data-like-btn="${esc(model.id)}:${esc(card.id)}"
              onclick="handleLikeCard('${esc(model.id)}', '${esc(card.id)}')"
              aria-label="${liked ? 'いいねを取り消す' : 'いいね'}">
        ${liked ? '♥' : '♡'}
      </button>
    </div>
  `;
}

/** 未来時代プレースホルダー（社会人の点線枠など） */
function renderModelFutureEra(era, model) {
  return html`
    <div class="model-era">
      <div class="model-era-bar model-era-bar-future">
        <span class="model-era-name">${esc(getEraEnLabel(era))} / ${esc(ERA_LABEL[era])}</span>
      </div>
      <div class="model-era-body">
        <div class="model-future-card">
          <div class="model-future-card-text">${esc(model.display_name)}さんがこれから書いていきます</div>
        </div>
      </div>
    </div>
  `;
}

/* ========== モデル詳細用ヘルパー ========== */

/** モデルの「未来の時代」を返す。在学中なら卒業後、卒業生なら null */
function getFutureEra(model) {
  if (model.status === 'sotsugyo') return null;
  if (model.current_year === 'daigaku_4' || model.current_year === 'daigaku_3') {
    // 大3〜大4なら社会人が次
    return 'shakaijin';
  }
  return null;
}

/** era ID から表示用の番号（01, 02, ...）を返す */
function getEraNumber(era) {
  const map = {
    daigaku_1: '01',
    daigaku_2: '02',
    daigaku_3: '03',
    daigaku_4: '04',
    shakaijin: '05',
    kokou: '00',
    pre: '00',
  };
  return map[era] || '';
}

/** era ID から英ラベルを返す */
function getEraEnLabel(era) {
  const map = {
    pre: 'PRE-KOKOU',
    kokou: 'KOKOU',
    daigaku_1: 'DAIGAKU 1NEN',
    daigaku_2: 'DAIGAKU 2NEN',
    daigaku_3: 'DAIGAKU 3NEN',
    daigaku_4: 'DAIGAKU 4NEN',
    shakaijin: 'SHAKAIJIN',
  };
  return map[era] || '';
}

/** 保存済みか判定 */
function isCardSaved(modelId, cardId) {
  return Store.userPlan.cards.some(c =>
    c.parent === cardId || (c.parent_model_id === modelId && c.parent === cardId)
  );
}

/** いいね済みか判定 */
function isCardLiked(modelId, cardId) {
  const key = `${modelId}:${cardId}`;
  return Store.userPlan.liked_card_ids?.includes(key);
}

/* ============================================================
   オリジナルカード作成（じぶんで立てる）
   ============================================================ */
function renderCreateCard(qs) {
  const body = document.getElementById('remix-body');
  const params = new URLSearchParams(qs || '');
  const preStage = params.get('stage') || '';

  const catOptions = Object.entries(CATEGORY_LABEL).map(([k, v]) =>
    html`<option value="${k}" ${k === 'skill' ? 'selected' : ''}>${esc(v)}</option>`
  ).join('');

  body.innerHTML = html`
    <div class="modal-grab"></div>
    <button class="remix-close" onclick="closeModal()" aria-label="閉じる">✕</button>

    <div class="remix-your-stamp create-stamp">
      ORIGINAL
      <span class="remix-your-stamp-sub">／ じぶんのカード</span>
    </div>
    <div class="create-lead">
      先輩の真似じゃない、自分発の一歩。<br>
      <strong>NAZE（なぜ）</strong>から書けると、計画は強くなります。
    </div>

    <form id="create-form" onsubmit="return false;">

      <div class="field">
        <div class="field-label-row">
          <span class="label-en">WHEN / いつ</span>
          <span class="label-hint">置く時期</span>
        </div>
        <div class="remix-when-row">
          ${renderStageSelect(preStage)}
          <input class="input" type="text" name="duration" placeholder="期間（例：2週間）">
        </div>
      </div>

      <div class="field">
        <div class="field-label-row">
          <span class="label-en">WHAT / 何をする</span>
          <span class="label-hint">行動で書く</span>
        </div>
        <input class="input" type="text" name="what" maxlength="60" placeholder="例：短編を1本完成させて学内上映に出す">
      </div>

      <div class="remix-why-field">
        <div class="field-label-row">
          <span class="label-en">NAZE / なぜ</span>
          <span class="remix-why-core-tag">★ カードの核</span>
        </div>
        <textarea class="remix-why-input" name="why" placeholder="なぜ自分はこれをやる？（あとからでもOK）"></textarea>
      </div>

      <div class="field">
        <div class="field-label-row">
          <span class="label-en">CATEGORY / 分類</span>
        </div>
        <select class="input" name="category">${catOptions}</select>
      </div>

      <div class="field">
        <div class="field-label-row">
          <span class="label-en">RESULT / 結果</span>
          <span class="label-hint">目標は今・ふりかえりは未来の自分が</span>
        </div>
        <div class="remix-result-stack">
          <div>
            <div class="remix-subfield-label">MOKUHYOU / 目標</div>
            <input class="input" type="text" name="goal" placeholder="このカードで達成したいこと">
          </div>
          <div>
            <div class="remix-subfield-label">FURIKAERI / ふりかえり</div>
            <div class="remix-locked-field">
              <span class="remix-lock-mark">🔒 LOCKED</span>
              ここは、実行した後の自分が書く場所
            </div>
          </div>
        </div>
      </div>

      <div class="remix-parent-confirm create-origin-note">
        <span class="remix-parent-icon">✎</span>
        <div>
          このカードは <strong>あなた発のオリジナル</strong> として記録されます。<br>
          <span class="remix-parent-sub">将来あなたがモデルになった時、誰かがここから派生するかもしれません。</span>
        </div>
      </div>

      <div class="remix-cta-row">
        <button type="button" class="remix-cta-primary" onclick="submitCreateCard()">▶ 計画に追加する</button>
        <button type="button" class="remix-cta-secondary" onclick="closeModal()">キャンセル</button>
      </div>
      <div class="remix-cta-hint">— 後からいつでも編集できます —</div>
    </form>
  `;
}

window.submitCreateCard = function() {
  const form = document.getElementById('create-form');
  if (!form) return;
  const formData = new FormData(form);
  const stage = formData.get('stage');
  const what = formData.get('what')?.trim();
  const why = formData.get('why')?.trim();
  const goal = formData.get('goal')?.trim();

  if (!stage) { showToast('いつのカードか選んでください', 'warn'); return; }
  if (!what) { showToast('何をするか入力してください', 'warn'); return; }

  addCardToPlan({
    when: { stage, duration: formData.get('duration')?.trim() || '' },
    what,
    why: why || '',
    category: formData.get('category') || 'skill',
    parent: null,
    state: 'planned',
    org: null,
    result: { goal: goal || null, reflection: null },
  });
  showToast('オリジナルカードを計画に追加しました', 'success');
  setTimeout(() => navigateTo('#/plan'), 500);
};

function renderRemix(modelId, cardId) {
  const body = document.getElementById('remix-body');
  const model = getModel(modelId);
  const origCard = model?.cards?.find(c => c.id === cardId);

  if (!model || !origCard) {
    body.innerHTML = html`
      <div class="modal-grab"></div>
      <div class="remix-not-found">
        <div class="remix-not-found-title">カードが見つかりませんでした</div>
        <button class="btn mt-3" onclick="closeModal()">閉じる</button>
      </div>
    `;
    return;
  }

  body.innerHTML = renderRemixContent(model, origCard);

  // フォーム要素にイベントを紐づける
  attachRemixFormHandlers(model, origCard);
}

/** リミックスシートの中身を組み立てる */
function renderRemixContent(model, origCard) {
  const origStage = origCard.when?.stage || 'daigaku_1_zenki';
  const origDuration = origCard.when?.duration || '';
  const origCategory = origCard.category || 'skill';

  return html`
    <div class="modal-grab"></div>

    <div class="remix-head">
      <div class="remix-head-text">
        <div class="remix-label">REMIX SHEET / 計画に追加</div>
        <div class="remix-title">先輩のハックを<br>自分のカードにする</div>
      </div>
      <button class="remix-close" onclick="closeModal()" aria-label="閉じる">✕</button>
    </div>

    <div class="remix-from-line">
      <span class="remix-person-tag">${esc(model.handle.toUpperCase())}</span>の<br>
      <strong>「${esc(origCard.what)}」</strong>を保存します
    </div>

    <div class="remix-original">
      <span class="remix-original-tag">先輩のカード</span>
      <div class="remix-original-when">${esc(stageLabel(origStage))}${origDuration ? ` ・ ${esc(origDuration)}` : ''}</div>
      <div class="remix-original-what">${esc(origCard.what)}</div>
    </div>

    <div class="remix-arrow">
      ↓ ↓ ↓
      <span class="remix-arrow-label">REMIX / あなた色に染める</span>
    </div>

    <div class="remix-your-stamp">
      YOUR VERSION
      <span class="remix-your-stamp-sub">／ あなたのカード</span>
    </div>

    <form id="remix-form" onsubmit="return false;">

      <!-- WHEN -->
      <div class="field">
        <div class="field-label-row">
          <span class="label-en">WHEN / いつ</span>
          <span class="label-hint">置く時期</span>
        </div>
        <div class="remix-when-row">
          ${renderStageSelect(origStage)}
          <input class="input" type="text" name="duration" value="${esc(origDuration)}" placeholder="期間（例：2週間）">
        </div>
      </div>

      <!-- WHAT -->
      <div class="field">
        <div class="field-label-row">
          <span class="label-en">WHAT / 何をする</span>
          <span class="label-hint">編集できます</span>
        </div>
        <input class="input" type="text" name="what" value="${esc(origCard.what)}" maxlength="60">
      </div>

      <!-- WHY (the core of remix) -->
      <div class="remix-why-field">
        <div class="field-label-row">
          <span class="label-en">NAZE / なぜ</span>
          <span class="remix-why-core-tag">★ remixの核</span>
        </div>
        ${origCard.why ? html`
          <div class="remix-why-original">
            ${esc(origCard.why)}
          </div>
          <div class="remix-why-arrow">
            ↓
            <span class="remix-why-arrow-label">あなたなら、なぜこの行動をする？</span>
          </div>
        ` : ''}
        <textarea class="remix-why-input" name="why" placeholder="自分の言葉で書く（あとからでもOK）" data-original-why="${esc(origCard.why || '')}"></textarea>
        ${origCard.why ? html`
          <div class="remix-why-helpers">
            <button type="button" class="remix-why-quick" onclick="remixCopyOriginalWhy()">↩ 元のままコピー</button>
            <button type="button" class="remix-why-quick" onclick="remixClearWhy()">空白に戻す</button>
          </div>
        ` : ''}
      </div>

      <!-- RESULT -->
      <div class="field">
        <div class="field-label-row">
          <span class="label-en">RESULT / 結果</span>
          <span class="label-hint">目標は今書く・ふりかえりは未来の自分が</span>
        </div>
        <div class="remix-result-stack">
          <div>
            <div class="remix-subfield-label">MOKUHYOU / 目標</div>
            <input class="input" type="text" name="goal" value="${esc(origCard.result?.goal || '')}" placeholder="このカードで達成したいこと">
          </div>
          <div>
            <div class="remix-subfield-label">FURIKAERI / ふりかえり</div>
            <div class="remix-locked-field">
              <span class="remix-lock-mark">🔒 LOCKED</span>
              ここは、実行した後の自分が書く場所
            </div>
          </div>
        </div>
      </div>

      <!-- Meta -->
      <div class="remix-meta-row">
        <div class="remix-meta-chip">
          <span class="remix-meta-key">CATEGORY</span>
          <span class="remix-meta-val">${esc(CATEGORY_LABEL[origCategory] || origCategory)}</span>
        </div>
        <div class="remix-meta-chip">
          <span class="remix-meta-key">ORG</span>
          <span class="remix-meta-val">${origCard.org ? esc(shortenOrgName(getOrg(origCard.org)?.name || origCard.org)) : '未設定'}</span>
        </div>
      </div>

      <!-- Parent link confirmation -->
      <div class="remix-parent-confirm">
        <span class="remix-parent-icon">↳</span>
        <div>
          このカードは <strong>${esc(model.handle.toUpperCase())} の「${esc(truncate(origCard.what, 14))}」カードから派生</strong> として記録されます。<br>
          <span class="remix-parent-sub">将来あなたがモデルになった時、辿った道筋として残ります。</span>
        </div>
      </div>

      <!-- CTA -->
      <div class="remix-cta-row">
        <button type="button" class="remix-cta-primary" onclick="submitRemix('${esc(model.id)}', '${esc(origCard.id)}')">▶ 計画に追加する</button>
        <button type="button" class="remix-cta-secondary" onclick="closeModal()">キャンセル</button>
      </div>

      <div class="remix-cta-hint">— 後からいつでも編集できます —</div>

    </form>
  `;
}

/** stage select の生成 */
function renderStageSelect(currentStage) {
  const options = [
    ...(!currentStage ? [{ value: '', label: '— 時期を選ぶ —', disabled: false }] : []),
    { value: '', label: '── 高校以前 ──', disabled: true },
    { value: 'shougakkou', label: '小学' },
    { value: 'chuugakkou', label: '中学' },
    { value: 'kokou_1', label: '高1' },
    { value: 'kokou_2', label: '高2' },
    { value: 'kokou_3', label: '高3' },
    { value: '', label: '── 大学 ──', disabled: true },
    { value: 'daigaku_1_zenki', label: '大学1年 前期' },
    { value: 'daigaku_1_kouki', label: '大学1年 後期' },
    { value: 'daigaku_1_tsunen', label: '大学1年 通年' },
    { value: 'daigaku_2_zenki', label: '大学2年 前期' },
    { value: 'daigaku_2_kouki', label: '大学2年 後期' },
    { value: 'daigaku_2_tsunen', label: '大学2年 通年' },
    { value: 'daigaku_3_zenki', label: '大学3年 前期' },
    { value: 'daigaku_3_kouki', label: '大学3年 後期' },
    { value: 'daigaku_3_tsunen', label: '大学3年 通年' },
    { value: 'daigaku_4_zenki', label: '大学4年 前期' },
    { value: 'daigaku_4_kouki', label: '大学4年 後期' },
    { value: 'daigaku_4_tsunen', label: '大学4年 通年' },
    { value: '', label: '── 卒業後 ──', disabled: true },
    { value: 'shakaijin', label: '社会人' },
  ];

  return html`
    <select class="select" name="stage">
      ${options.map(o => html`
        <option value="${esc(o.value)}"
                ${o.disabled ? 'disabled' : ''}
                ${(o.value && o.value === currentStage) || (!currentStage && !o.value && !o.disabled) ? 'selected' : ''}>
          ${esc(o.label)}
        </option>
      `).join('')}
    </select>
  `;
}

/** リミックスフォームのイベントハンドラを紐づける */
function attachRemixFormHandlers(model, origCard) {
  // フォーム表示後にフォーカスを WHY に当てる（remixの核なので）
  setTimeout(() => {
    const whyInput = document.querySelector('.remix-why-input');
    if (whyInput) {
      // フォーカスはユーザーの操作を待つ（モバイルでキーボードが勝手に開かないように）
    }
  }, 100);
}

/** 短く切り詰めるヘルパー */
function truncate(text, maxLen) {
  if (!text) return '';
  if (text.length <= maxLen) return text;
  return text.slice(0, maxLen) + '…';
}

/* ========== リミックスフォーム操作 ========== */

/** 「↩ 元のままコピー」 */
window.remixCopyOriginalWhy = function() {
  const input = document.querySelector('.remix-why-input');
  if (!input) return;
  input.value = input.dataset.originalWhy || '';
  input.focus();
};

/** 「空白に戻す」 */
window.remixClearWhy = function() {
  const input = document.querySelector('.remix-why-input');
  if (!input) return;
  input.value = '';
  input.focus();
};

/** 「▶ 計画に追加する」のサブミット */
window.submitRemix = function(modelId, parentCardId) {
  const model = getModel(modelId);
  const origCard = model?.cards?.find(c => c.id === parentCardId);
  if (!model || !origCard) {
    showToast('カード情報の取得に失敗しました', 'warn');
    return;
  }

  const form = document.getElementById('remix-form');
  if (!form) return;

  const formData = new FormData(form);
  const stage = formData.get('stage')?.trim();
  const duration = formData.get('duration')?.trim();
  const what = formData.get('what')?.trim();
  const why = formData.get('why')?.trim();
  const goal = formData.get('goal')?.trim();

  // バリデーション：最低限 stage と what は必須
  if (!stage) {
    showToast('いつのカードか選んでください', 'warn');
    return;
  }
  if (!what) {
    showToast('何をするか入力してください', 'warn');
    return;
  }

  // ユーザー計画に追加
  const newCard = {
    when: {
      stage: stage,
      duration: duration || '',
    },
    what: what,
    why: why || '',
    category: origCard.category || 'skill',
    parent: origCard.id,
    parent_model_id: model.id,
    parent_handle: model.handle,
    parent_original_why: origCard.why || '',
    state: 'planned',
    org: origCard.org || null,
    result: {
      goal: goal || null,
      reflection: null,
    },
  };

  addCardToPlan(newCard);
  showToast('計画に追加しました', 'success');

  // 計画ページへ遷移
  setTimeout(() => {
    navigateTo('#/plan');
  }, 500);
};

function renderApply() {
  const body = document.getElementById('apply-body');
  body.innerHTML = renderApplyContent();
  attachApplyEventHandlers();
}

/** 申請フォームの中身を組み立てる */
function renderApplyContent() {
  const readiness = checkReadiness();
  const cards = Store.userPlan.cards || [];

  if (cards.length === 0) {
    return renderApplyEmpty();
  }

  return [
    renderApplyHero(readiness),
    renderApplyReadinessPanel(readiness, cards),
    renderApplySection1(),  // サブタイトル＋bio
    renderApplySection2(),  // 系統選択
    renderApplySection3(),  // 団体
    renderApplySection4(),  // コラボ
    renderApplySection5(),  // 公開範囲
    renderApplySubmit(readiness),
  ].join('');
}

/** カードがない状態：申請できない */
function renderApplyEmpty() {
  return html`
    <div class="apply-empty">
      <div class="apply-empty-title">まだ申請できません</div>
      <div class="apply-empty-body">
        申請には、計画ページにカードが必要です。<br>
        まずは先輩のカードを保存するか、自分のカードを書いてみましょう。
      </div>
      <a class="btn-cta" href="#/home">▶ 先輩を探す</a>
    </div>
  `;
}

/** ヒーローバナー */
function renderApplyHero(readiness) {
  return html`
    <div class="apply-hero">
      <div class="apply-hero-stamp">SHINKOCHU</div>
      <div class="apply-label">MODEL APPLICATION / モデル申請</div>
      <div class="apply-title">後輩に渡す道として<br>公開する</div>
      <div class="apply-sub">
        ${readiness.all_met
          ? html`<strong>4条件すべて達成</strong>。完成版じゃなくていい、<strong>進行中の道</strong>として、次の人の参考になります。`
          : html`公開できる状態にあと <strong>${readiness.total_conditions - readiness.conditions_met}つ</strong>。完成じゃなくていい、<strong>進行中の道</strong>として、次の人の参考になります。`}
      </div>
    </div>
  `;
}

/** READINESS 詳細パネル */
function renderApplyReadinessPanel(readiness, cards) {
  // 各条件に対応する詳細情報を出す
  const stages = new Set(cards.filter(c => c.state === 'reflected').map(c => c.when?.stage).filter(Boolean));
  const reflected = cards.filter(c => c.state === 'reflected');
  const remixed = cards.filter(c => c.parent);
  const original = cards.filter(c => !c.parent);

  const items = [
    {
      key: 'spans_multiple_terms',
      label: '2つ以上の学期にカード',
      met: readiness.conditions.spans_multiple_terms,
      detail: stages.size > 0 ? `${stages.size}学期に分布` : '対象カードなし',
    },
    {
      key: 'all_cards_have_why',
      label: 'ふりかえり済みカードに why と reflection',
      met: readiness.conditions.all_cards_have_why,
      detail: `ふりかえり済み ${reflected.length} 枚`,
    },
    {
      key: 'majority_remixed_why',
      label: 'remix の why を自分の言葉で',
      met: readiness.conditions.majority_remixed_why,
      detail: remixed.length > 0 ? `アレンジ ${remixed.length} 枚` : 'remix なし',
    },
    {
      key: 'has_original_card',
      label: 'オリジナルカードが1枚以上',
      met: readiness.conditions.has_original_card,
      detail: original.length > 0 ? `${original.length} 枚` : 'まだなし',
    },
  ];

  const allMet = readiness.all_met;
  const headerText = allMet ? '申請レディネス・達成' : `あと ${readiness.total_conditions - readiness.conditions_met} つで申請可能`;

  return html`
    <div class="apply-readiness">
      <div class="apply-readiness-head">
        <span class="apply-readiness-label">READINESS</span>
        <span class="apply-readiness-stat">${readiness.conditions_met} / ${readiness.total_conditions}</span>
      </div>
      <div class="apply-readiness-title ${allMet ? 'apply-readiness-title-met' : ''}">${esc(headerText)}</div>
      <div class="apply-readiness-list">
        ${items.map(item => html`
          <div class="apply-readiness-item ${item.met ? 'apply-readiness-item-met' : 'apply-readiness-item-todo'}">
            <span class="apply-readiness-check">${item.met ? '✓' : '!'}</span>
            <div class="apply-readiness-item-text">
              <div class="apply-readiness-item-label">${esc(item.label)}</div>
              <div class="apply-readiness-item-detail">${esc(item.detail)}</div>
            </div>
          </div>
        `).join('')}
      </div>
      ${!allMet ? html`
        <div class="apply-readiness-hint">
          条件を満たすには、計画ページに戻ってカードを足したりふりかえりを書いたりしてください。
          <a class="apply-readiness-hint-link" href="#/plan">▶ 計画ページへ</a>
        </div>
      ` : ''}
    </div>
  `;
}

/** Section 1: サブタイトルと bio */
function renderApplySection1() {
  const profile = Store.userPlan.profile || {};
  return html`
    <div class="apply-section-head">
      <div class="apply-section-num">1</div>
      <div class="apply-section-title-block">
        <div class="apply-section-en">SUBTITLE</div>
        <div class="apply-section-jp">この道に名前をつける</div>
      </div>
    </div>

    <div class="panel">
      <div class="field">
        <div class="field-label-row">
          <span class="label-en">HANDLE / ハンドル</span>
          <span class="label-hint">@で始まる半角英数</span>
        </div>
        <input class="input" type="text" name="apply-handle" id="apply-handle"
               value="${esc(profile.handle || '')}" placeholder="@your_name" maxlength="20">
      </div>

      <div class="field">
        <div class="field-label-row">
          <span class="label-en">DISPLAY NAME / 表示名</span>
          <span class="label-hint">ニックネーム</span>
        </div>
        <input class="input" type="text" name="apply-display-name" id="apply-display-name"
               value="${esc(profile.display_name || '')}" placeholder="例：あいか" maxlength="20">
      </div>

      <div class="field">
        <div class="field-label-row">
          <span class="label-en">SUB-TITLE / サブタイトル</span>
          <span class="label-hint">15文字前後</span>
        </div>
        <input class="input" type="text" name="apply-subtitle" id="apply-subtitle"
               value="${esc(profile.subtitle || '')}" placeholder="例：映像制作で食べていく道" maxlength="30">
      </div>

      <div class="field">
        <div class="field-label-row">
          <span class="label-en">BIO / 一言で</span>
          <span class="label-hint">100〜200文字</span>
        </div>
        <textarea class="textarea" name="apply-bio" id="apply-bio"
                  rows="4" maxlength="300" placeholder="あなたがどんな大学生活を送ってきたか、簡潔に">${esc(profile.bio || '')}</textarea>
      </div>

      <div class="field">
        <div class="field-label-row">
          <span class="label-en">CAMPUS / 所属大学</span>
        </div>
        <input class="input" type="text" name="apply-campus" id="apply-campus"
               value="${esc(profile.campus || '')}" placeholder="例：○○大学" maxlength="50">
      </div>
    </div>
  `;
}

/** Section 2: 系統選択 */
function renderApplySection2() {
  const profile = Store.userPlan.profile || {};
  const selected = new Set(profile.keitou || []);

  return html`
    <div class="apply-section-head">
      <div class="apply-section-num">2</div>
      <div class="apply-section-title-block">
        <div class="apply-section-en">CATEGORY / KEITOU</div>
        <div class="apply-section-jp">どの系統に近い？</div>
      </div>
    </div>

    <div class="panel">
      <div class="field">
        <div class="field-label-row">
          <span class="label-en">KEITOU / 系統</span>
          <span class="label-hint">最大2つ・ハイブリッド可</span>
        </div>
        <div class="apply-keitou-grid">
          ${Store.keitou.map(k => html`
            <label class="apply-keitou-pill ${selected.has(k.id) ? 'apply-keitou-pill-selected' : ''}">
              <input type="checkbox" name="apply-keitou" value="${esc(k.id)}"
                     ${selected.has(k.id) ? 'checked' : ''}
                     onchange="handleKeitouChange(this)">
              <span class="keitou-dot keitou-dot--${esc(k.id)}"></span>
              <span class="apply-keitou-name">${esc(k.label_en)}</span>
            </label>
          `).join('')}
        </div>
        <div class="apply-hybrid-note">
          2つ選ぶと <strong>ハイブリッド</strong> として掲載されます（例：商社×起業家）。
        </div>
      </div>
    </div>
  `;
}

/** Section 3: 団体タグ */
function renderApplySection3() {
  const profile = Store.userPlan.profile || {};
  const orgs = profile.orgs || [];

  return html`
    <div class="apply-section-head">
      <div class="apply-section-num">3</div>
      <div class="apply-section-title-block">
        <div class="apply-section-en">ORG / DANTAI</div>
        <div class="apply-section-jp">所属している団体</div>
      </div>
    </div>

    <div class="panel">
      <div class="field">
        <div class="field-label-row">
          <span class="label-en">DANTAI / 団体</span>
          <span class="label-hint">勧誘ページとしても使える</span>
        </div>
        <div id="apply-orgs-list">
          ${orgs.length === 0
            ? html`<div class="apply-org-empty">まだ団体は登録されていません</div>`
            : orgs.map((orgEntry, i) => renderApplyOrgRow(orgEntry, i)).join('')}
        </div>
        <button type="button" class="apply-add-org" onclick="handleAddOrgRow()">＋ 団体を追加</button>
      </div>
    </div>
  `;
}

function renderApplyOrgRow(orgEntry, index) {
  // orgEntry: { type: 'saakuru'|'intern'|'other', name: '...' }
  return html`
    <div class="apply-org-row" data-index="${index}">
      <select class="apply-org-type" onchange="handleOrgTypeChange(${index}, this.value)">
        <option value="saakuru" ${orgEntry.type === 'saakuru' ? 'selected' : ''}>SAA-KURU</option>
        <option value="intern" ${orgEntry.type === 'intern' ? 'selected' : ''}>INTERN</option>
        <option value="seminar" ${orgEntry.type === 'seminar' ? 'selected' : ''}>SEMINAR</option>
        <option value="other" ${orgEntry.type === 'other' ? 'selected' : ''}>OTHER</option>
      </select>
      <input class="apply-org-name" type="text" placeholder="団体名"
             value="${esc(orgEntry.name || '')}"
             onchange="handleOrgNameChange(${index}, this.value)">
      <button type="button" class="apply-org-x" onclick="handleRemoveOrgRow(${index})" aria-label="削除">✕</button>
    </div>
  `;
}

/** Section 4: コラボ受付 */
function renderApplySection4() {
  const profile = Store.userPlan.profile || {};
  const collab = profile.collab || { open: ['interview', 'mentoring', 'talk'], contact_method: 'in_app_dm', contact_value: '' };
  const openSet = new Set(collab.open || []);

  const collabOptions = [
    { id: 'interview', label: '取材' },
    { id: 'mentoring', label: 'メンタリング' },
    { id: 'talk', label: '登壇' },
    { id: 'recruit', label: '採用相談' },
  ];

  return html`
    <div class="apply-section-head">
      <div class="apply-section-num">4</div>
      <div class="apply-section-title-block">
        <div class="apply-section-en">COLLAB</div>
        <div class="apply-section-jp">受け付けるコラボ</div>
      </div>
    </div>

    <div class="panel">
      <div class="field">
        <div class="field-label-row">
          <span class="label-en">UKETSUKE / 受付窓</span>
          <span class="label-hint">いつでも変更OK</span>
        </div>
        <div class="apply-collab-grid">
          ${collabOptions.map(opt => html`
            <label class="apply-collab-toggle ${openSet.has(opt.id) ? 'apply-collab-toggle-on' : ''}">
              <input type="checkbox" name="apply-collab" value="${esc(opt.id)}"
                     ${openSet.has(opt.id) ? 'checked' : ''}
                     onchange="handleCollabToggle(this)">
              <span class="apply-toggle-mark">${openSet.has(opt.id) ? '✓' : ''}</span>
              <span>${esc(opt.label)}</span>
            </label>
          `).join('')}
        </div>
      </div>

      <div class="field">
        <div class="field-label-row">
          <span class="label-en">CONNECT / 連絡方法</span>
        </div>
        <div class="apply-contact-row">
          <select class="apply-contact-method" name="apply-contact-method" id="apply-contact-method">
            <option value="in_app_dm" ${collab.contact_method === 'in_app_dm' ? 'selected' : ''}>DAIHACK内DM</option>
            <option value="email" ${collab.contact_method === 'email' ? 'selected' : ''}>メール</option>
            <option value="x" ${collab.contact_method === 'x' ? 'selected' : ''}>X (旧Twitter)</option>
          </select>
          <input class="apply-contact-value" type="text" name="apply-contact-value" id="apply-contact-value"
                 value="${esc(collab.contact_value || '')}"
                 placeholder="${collab.contact_method === 'in_app_dm' ? '（アプリ内で完結）' : 'メールまたは@ID'}">
        </div>
      </div>
    </div>
  `;
}

/** Section 5: 公開範囲ダイヤル */
function renderApplySection5() {
  const profile = Store.userPlan.profile || {};
  const visibility = profile.visibility || 'nickname';

  const options = [
    { id: 'full', title: 'フル公開', desc: '実名・顔・所属大学すべて' },
    { id: 'nickname', title: 'ニックネーム公開', desc: 'ハンドル / 所属大学公開 / 顔は非公開でOK' },
    { id: 'campus_only', title: '大学のみ公開', desc: '所属大学の新入生だけが見られる' },
  ];

  return html`
    <div class="apply-section-head">
      <div class="apply-section-num">5</div>
      <div class="apply-section-title-block">
        <div class="apply-section-en">VISIBILITY</div>
        <div class="apply-section-jp">公開の濃さ</div>
      </div>
    </div>

    <div class="panel">
      <div class="field">
        <div class="field-label-row">
          <span class="label-en">KOUKAI / 濃淡ダイヤル</span>
          <span class="label-hint">正直に書く × 公開範囲は別物</span>
        </div>
        <div class="apply-visibility-list">
          ${options.map(opt => html`
            <label class="apply-vis-row ${visibility === opt.id ? 'apply-vis-row-selected' : ''}">
              <input type="radio" name="apply-visibility" value="${esc(opt.id)}"
                     ${visibility === opt.id ? 'checked' : ''}
                     onchange="handleVisibilityChange(this)">
              <span class="apply-vis-radio"></span>
              <div class="apply-vis-content">
                <div class="apply-vis-title">${esc(opt.title)}</div>
                <div class="apply-vis-desc">${esc(opt.desc)}</div>
              </div>
            </label>
          `).join('')}
        </div>
      </div>
    </div>
  `;
}

/** サブミットブロック */
function renderApplySubmit(readiness) {
  const ready = readiness.all_met;

  return html`
    <div class="apply-submit-block">
      <div class="apply-submit-summary">
        申請後、申請内容を <strong>JSON ファイル</strong>としてダウンロードし、運営に送付してください。
        運営が <strong>1〜3日</strong> で内容を確認し、承認されたら <strong>SHINKOCHU（進行中）</strong> として公開されます。<br>
        カードは <strong>あとからいつでも追加・編集</strong> できます。
      </div>
      <button type="button"
              class="apply-submit-cta ${ready ? '' : 'apply-submit-cta-disabled'}"
              onclick="submitApplication()"
              ${ready ? '' : 'disabled'}>
        ${ready ? '▶ 申請を確定し JSON を出力' : `▶ あと${readiness.total_conditions - readiness.conditions_met}つで申請可能`}
      </button>
      ${!ready ? html`
        <div class="apply-submit-hint">
          ※ 残りの条件を満たすには、計画ページでカードを足してください
        </div>
      ` : html`
        <div class="apply-submit-hint">
          JSON ダウンロード後の手順は、ダウンロード後に表示されます
        </div>
      `}
    </div>
  `;
}

/* ========== Apply form event handlers ========== */

function attachApplyEventHandlers() {
  // 各種入力の値を自動的に Store.userPlan.profile に反映する
  ['apply-handle', 'apply-display-name', 'apply-subtitle', 'apply-bio', 'apply-campus'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('input', () => persistProfileField(id, el.value));
      el.addEventListener('blur', () => persistProfileField(id, el.value));
    }
  });

  const contactMethod = document.getElementById('apply-contact-method');
  const contactValue = document.getElementById('apply-contact-value');
  if (contactMethod) {
    contactMethod.addEventListener('change', () => {
      ensureCollab();
      Store.userPlan.profile.collab.contact_method = contactMethod.value;
      // プレースホルダー更新
      if (contactValue) {
        contactValue.placeholder = contactMethod.value === 'in_app_dm' ? '（アプリ内で完結）' : 'メールまたは@ID';
      }
      saveUserPlan();
    });
  }
  if (contactValue) {
    contactValue.addEventListener('input', () => {
      ensureCollab();
      Store.userPlan.profile.collab.contact_value = contactValue.value;
      saveUserPlan();
    });
  }
}

function ensureProfile() {
  if (!Store.userPlan.profile) Store.userPlan.profile = {};
}

function ensureCollab() {
  ensureProfile();
  if (!Store.userPlan.profile.collab) {
    Store.userPlan.profile.collab = { open: [], closed: [], contact_method: 'in_app_dm', contact_value: '' };
  }
}

function persistProfileField(id, value) {
  ensureProfile();
  const key = id.replace('apply-', '').replace(/-/g, '_');
  Store.userPlan.profile[key] = value;
  saveUserPlan();
}

window.handleKeitouChange = function(input) {
  ensureProfile();
  if (!Store.userPlan.profile.keitou) Store.userPlan.profile.keitou = [];
  const k = Store.userPlan.profile.keitou;

  if (input.checked) {
    // 最大2つまで
    if (k.length >= 2) {
      input.checked = false;
      showToast('系統は最大2つまで', 'warn');
      return;
    }
    if (!k.includes(input.value)) k.push(input.value);
  } else {
    const idx = k.indexOf(input.value);
    if (idx >= 0) k.splice(idx, 1);
  }
  saveUserPlan();
  // 見た目を更新（selected クラスの再付与）
  handleRouteChange();
};

window.handleCollabToggle = function(input) {
  ensureCollab();
  const open = Store.userPlan.profile.collab.open || [];
  if (input.checked) {
    if (!open.includes(input.value)) open.push(input.value);
  } else {
    const idx = open.indexOf(input.value);
    if (idx >= 0) open.splice(idx, 1);
  }
  Store.userPlan.profile.collab.open = open;
  saveUserPlan();
  // ラベル選択状態を更新（簡易再描画）
  input.closest('.apply-collab-toggle').classList.toggle('apply-collab-toggle-on', input.checked);
  input.closest('.apply-collab-toggle').querySelector('.apply-toggle-mark').textContent = input.checked ? '✓' : '';
};

window.handleVisibilityChange = function(input) {
  ensureProfile();
  Store.userPlan.profile.visibility = input.value;
  saveUserPlan();
  // 選択状態を更新
  document.querySelectorAll('.apply-vis-row').forEach(row => {
    const radio = row.querySelector('input[type="radio"]');
    row.classList.toggle('apply-vis-row-selected', radio.value === input.value);
  });
};

window.handleAddOrgRow = function() {
  ensureProfile();
  if (!Store.userPlan.profile.orgs) Store.userPlan.profile.orgs = [];
  Store.userPlan.profile.orgs.push({ type: 'saakuru', name: '' });
  saveUserPlan();
  handleRouteChange();
};

window.handleRemoveOrgRow = function(index) {
  ensureProfile();
  if (!Store.userPlan.profile.orgs) return;
  Store.userPlan.profile.orgs.splice(index, 1);
  saveUserPlan();
  handleRouteChange();
};

window.handleOrgTypeChange = function(index, value) {
  ensureProfile();
  if (!Store.userPlan.profile.orgs?.[index]) return;
  Store.userPlan.profile.orgs[index].type = value;
  saveUserPlan();
};

window.handleOrgNameChange = function(index, value) {
  ensureProfile();
  if (!Store.userPlan.profile.orgs?.[index]) return;
  Store.userPlan.profile.orgs[index].name = value;
  saveUserPlan();
};

/* ========== 申請サブミット ========== */

window.submitApplication = function() {
  const readiness = checkReadiness();
  if (!readiness.all_met) {
    showToast('まだ申請できる状態にありません', 'warn');
    return;
  }

  const profile = Store.userPlan.profile || {};

  // 必須項目チェック
  const required = [
    { key: 'handle', label: 'ハンドル' },
    { key: 'display_name', label: '表示名' },
    { key: 'subtitle', label: 'サブタイトル' },
    { key: 'campus', label: '所属大学' },
  ];
  for (const r of required) {
    if (!profile[r.key] || profile[r.key].trim().length === 0) {
      showToast(`${r.label}を入力してください`, 'warn');
      const el = document.getElementById(`apply-${r.key.replace(/_/g, '-')}`);
      if (el) el.focus();
      return;
    }
  }

  // ハンドルのバリデーション
  if (!/^@[a-z0-9_]{3,20}$/.test(profile.handle)) {
    showToast('ハンドルは @ + 半角英数3〜20文字', 'warn');
    return;
  }

  if (!profile.keitou || profile.keitou.length === 0) {
    showToast('系統を1つ以上選択してください', 'warn');
    return;
  }

  // JSON ペイロード組み立て
  const payload = buildApplicationPayload(profile, readiness);

  // スキーマ自己検証（schema が読めている場合のみ。サニタイズの最終確認）
  if (Store.applicationSchema) {
    const schemaErrors = validateAgainstSchema(payload, Store.applicationSchema);
    if (schemaErrors.length > 0) {
      console.error('Application schema validation failed:', schemaErrors);
      showToast('申請データの形式に問題があります。入力を確認してください', 'warn');
      return;
    }
  }

  // ダウンロード
  const downloaded = downloadApplicationJSON(payload);

  // 完了画面表示
  showApplyComplete(payload, downloaded);
};

/* ============================================================
   軽量 JSON Schema バリデータ（申請JSONの自己検証用）
   application-schema.json が使う機能のみ対応:
   type / enum / required / properties / items / $ref / minItems /
   maxItems / maxLength / pattern。外部ライブラリ不要。
   ============================================================ */
function validateAgainstSchema(data, schema, root, path = '') {
  root = root || schema;
  const errors = [];
  if (!schema) return errors;

  // $ref 解決（このスキーマは #/definitions/card のみ）
  if (schema.$ref) {
    const ref = schema.$ref.replace(/^#\//, '').split('/');
    let target = root;
    for (const seg of ref) target = target?.[seg];
    return validateAgainstSchema(data, target, root, path);
  }

  const typeOf = (v) => Array.isArray(v) ? 'array' : (v === null ? 'null' : typeof v === 'number'
    ? (Number.isInteger(v) ? 'integer' : 'number') : typeof v);

  if (schema.type) {
    const types = Array.isArray(schema.type) ? schema.type : [schema.type];
    const actual = typeOf(data);
    const ok = types.some(t => t === actual || (t === 'number' && actual === 'integer'));
    if (!ok) { errors.push(`${path || '(root)'}: type は ${types.join('|')} ですが ${actual} です`); return errors; }
  }

  if (schema.enum && !schema.enum.includes(data)) {
    errors.push(`${path}: ${JSON.stringify(data)} は許可された値ではありません`);
  }
  if (typeof data === 'string') {
    if (schema.maxLength != null && data.length > schema.maxLength)
      errors.push(`${path}: ${data.length}文字（上限${schema.maxLength}）`);
    if (schema.pattern && !new RegExp(schema.pattern).test(data))
      errors.push(`${path}: パターン ${schema.pattern} に一致しません`);
  }
  if (Array.isArray(data)) {
    if (schema.minItems != null && data.length < schema.minItems)
      errors.push(`${path}: 要素${data.length}個（最小${schema.minItems}）`);
    if (schema.maxItems != null && data.length > schema.maxItems)
      errors.push(`${path}: 要素${data.length}個（最大${schema.maxItems}）`);
    if (schema.items) data.forEach((item, i) =>
      errors.push(...validateAgainstSchema(item, schema.items, root, `${path}[${i}]`)));
  }
  if (data && typeof data === 'object' && !Array.isArray(data)) {
    (schema.required || []).forEach(key => {
      if (!(key in data)) errors.push(`${path}: 必須項目 "${key}" がありません`);
    });
    if (schema.properties) {
      for (const [key, sub] of Object.entries(schema.properties)) {
        if (key in data) errors.push(...validateAgainstSchema(data[key], sub, root, path ? `${path}.${key}` : key));
      }
    }
  }
  return errors;
}

function buildApplicationPayload(profile, readiness) {
  const cards = Store.userPlan.cards || [];

  // --- スキーマ準拠のサニタイズ ---
  const clamp = (v, max) => {
    const s = (v == null ? '' : String(v));
    return s.length > max ? s.slice(0, max) : s;
  };
  const VALID_KEITOU = ['shosha', 'startup', 'scholar', 'creator', 'global'];
  const VALID_COLLAB = ['interview', 'mentoring', 'talk', 'recruit'];
  const VALID_CATEGORY = ['academic', 'career', 'network', 'skill', 'global'];
  const VALID_STAGE = [
    'shougakkou', 'chuugakkou', 'kokou_1', 'kokou_2', 'kokou_3',
    'daigaku_1_zenki', 'daigaku_1_kouki', 'daigaku_1_tsunen',
    'daigaku_2_zenki', 'daigaku_2_kouki', 'daigaku_2_tsunen',
    'daigaku_3_zenki', 'daigaku_3_kouki', 'daigaku_3_tsunen',
    'daigaku_4_zenki', 'daigaku_4_kouki', 'daigaku_4_tsunen', 'shakaijin',
  ];
  const clampNull = (v, max) => {
    if (v == null) return null;
    const s = String(v).trim();
    return s.length === 0 ? null : (s.length > max ? s.slice(0, max) : s);
  };

  const keitou = (profile.keitou || []).filter(k => VALID_KEITOU.includes(k)).slice(0, 2);
  const collabOpen = (profile.collab?.open || []).filter(k => VALID_COLLAB.includes(k));
  const avatarKeitou = VALID_KEITOU.includes(profile.keitou?.[0]) ? profile.keitou[0] : 'creator';

  return {
    meta: {
      submitted_at: new Date().toISOString(),
      app_version: APP_VERSION,
      readiness: {
        spans_multiple_terms: readiness.conditions.spans_multiple_terms,
        all_cards_have_why: readiness.conditions.all_cards_have_why,
        majority_remixed_why: readiness.conditions.majority_remixed_why,
        has_original_card: readiness.conditions.has_original_card,
      },
    },
    model: {
      handle: profile.handle,
      display_name: clamp(profile.display_name, 20),
      subtitle: clamp(profile.subtitle, 30),
      bio: clamp(profile.bio || '', 200),
      keitou: keitou,
      status: profile.current_year === 'shakaijin' ? 'sotsugyo' : 'shinkochu',
      current_year: profile.current_year || 'daigaku_2',
      graduation_year: profile.current_year === 'shakaijin'
        ? (Number.isInteger(profile.graduation_year) ? profile.graduation_year : new Date().getFullYear())
        : null,
      campus: profile.campus,
      orgs: (profile.orgs || [])
        .map(o => (typeof o === 'string' ? o : (o?.name || '')).trim())
        .filter(name => name.length > 0),
      collab: {
        open: collabOpen,
        closed: getClosedCollab(collabOpen),
        contact_method: ['in_app_dm', 'email', 'x'].includes(profile.collab?.contact_method)
          ? profile.collab.contact_method : 'in_app_dm',
        contact_value: profile.collab?.contact_value || '',
      },
      visibility: ['full', 'nickname', 'campus_only'].includes(profile.visibility)
        ? profile.visibility : 'nickname',
      avatar_keitou: avatarKeitou,
      avatar_seed: clamp((profile.display_name || '?')[0] || '?', 2),
      cards: cards.map(c => ({
        id: c.id,
        when: {
          stage: VALID_STAGE.includes(c.when?.stage) ? c.when.stage : 'daigaku_1_zenki',
          ...(c.when?.duration ? { duration: String(c.when.duration) } : {}),
        },
        what: clamp(c.what, 60),
        why: clamp(c.why, 200),
        category: VALID_CATEGORY.includes(c.category) ? c.category : 'skill',
        parent: c.parent || null,
        parent_handle: c.parent_handle || null,
        state: c.state === 'reflected' ? 'reflected' : 'planned',
        org: c.org || null,
        result: {
          goal: clampNull(c.result?.goal, 100),
          reflection: clampNull(c.result?.reflection, 300),
        },
      })),
    },
  };
}

function getClosedCollab(openList) {
  const all = ['interview', 'mentoring', 'talk', 'recruit'];
  return all.filter(k => !openList.includes(k));
}

function downloadApplicationJSON(payload) {
  const json = JSON.stringify(payload, null, 2);
  const handle = (payload.model.handle || 'unknown').replace(/^@/, '');
  const date = new Date().toISOString().slice(0, 10);
  const filename = `daihack-apply-${handle}-${date}.json`;
  try {
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return true;
  } catch (e) {
    // サンドボックス等でダウンロードがブロックされた場合はクリップボードへ
    try { navigator.clipboard?.writeText(json); } catch (_) {}
    return false;
  }
}

function showApplyComplete(payload, downloaded = true) {
  const json = JSON.stringify(payload, null, 2);
  const fname = `daihack-apply-${(payload.model.handle || '').replace(/^@/, '')}-${new Date().toISOString().slice(0,10)}.json`;
  const body = document.getElementById('apply-body');
  body.innerHTML = html`
    <div class="apply-complete">
      <div class="apply-complete-stamp">${downloaded ? '✓ DOWNLOADED' : '✓ READY'}</div>
      <div class="apply-complete-title">${downloaded ? html`申請ファイルを<br>ダウンロードしました` : html`申請内容が<br>できました`}</div>
      <div class="apply-complete-body">
        ${downloaded
          ? html`<p>あなたの申請内容を JSON ファイルとして保存しました。</p>`
          : html`<p>この環境では自動ダウンロードが使えないため、下のJSONをコピーして保存してください（クリップボードにもコピー済みです）。</p>
            <textarea class="apply-json-box" readonly onclick="this.select()">${esc(json)}</textarea>
            <button class="btn mt-2" onclick="navigator.clipboard?.writeText(this.previousElementSibling.value); showToast('コピーしました','success')">クリップボードにコピー</button>`}
        <p>次にやること:</p>
        <ol class="apply-complete-steps">
          <li>${downloaded ? html`ダウンロードした <code>${esc(fname)}</code> を確認` : html`コピーしたJSONを <code>${esc(fname)}</code> として保存`}</li>
          <li>運営に送付（メール／Slack／フォームなど）</li>
          <li>1〜3日後、SHINKOCHU として公開されます</li>
        </ol>
        <p class="apply-complete-note">
          公開後も <strong>カードは追加・編集できます</strong>。<br>
          ふりかえりを書き足すたび、あなたのページが更新されます。
        </p>
      </div>
      <div class="apply-complete-actions">
        <a class="btn-cta" href="#/plan">▶ 計画ページに戻る</a>
        <a class="btn" href="#/home">ホームへ</a>
      </div>
    </div>
  `;
}

function renderSettings() {
  const body = document.getElementById('settings-body');
  body.innerHTML = renderSettingsContent();
  attachSettingsEventHandlers();
}

function renderSettingsContent() {
  const profile = Store.userPlan.profile || {};
  const cards = Store.userPlan.cards || [];
  const reflected = cards.filter(c => c.state === 'reflected').length;

  return [
    renderSettingsHero(),
    renderSettingsProfile(profile),
    renderSettingsNotifications(),
    renderSettingsStats(cards, reflected),
    renderSettingsData(),
    renderSettingsAbout(),
  ].join('');
}

/** 通知設定 */
function renderSettingsNotifications() {
  const supported = browserNotifSupported();
  const enabled = !!Store.userPlan.notif_browser && supported
    && typeof Notification !== 'undefined' && Notification.permission === 'granted';

  return html`
    <div class="settings-section">
      <div class="settings-section-title">NOTIFICATION / 通知</div>
      <div class="settings-row">
        <div class="settings-row-text">
          <div class="settings-row-label">ブラウザ通知</div>
          <div class="settings-row-desc">
            ${supported
              ? '期限切れ・今日が期限のタスクを通知します（アプリを開いている間）'
              : 'この環境では利用できません。インストール版やブラウザで開くと使えます'}
          </div>
        </div>
        <button class="settings-toggle ${enabled ? 'settings-toggle-on' : ''}"
                onclick="handleBrowserNotifToggle()"
                ${supported ? '' : 'disabled'}>
          ${enabled ? 'ON' : 'OFF'}
        </button>
      </div>
      <div class="settings-row-note">アプリ内の通知（計画タブの🔔）は設定不要で動きます</div>
    </div>
  `;
}

/** ヒーロー */
function renderSettingsHero() {
  return html`
    <div class="settings-hero">
      <div class="settings-hero-label">SETTINGS / 設定</div>
      <div class="settings-hero-title">プロフィールとデータ</div>
      <div class="settings-hero-body">
        ここで設定した内容は申請フォームにも自動で反映されます。<br>
        申請前に下書きとして書き溜めるのもOK。
      </div>
    </div>
  `;
}

/** プロフィール編集 */
function renderSettingsProfile(profile) {
  return html`
    <div class="settings-section-head">
      <div class="settings-section-num">01</div>
      <div class="settings-section-title-block">
        <div class="settings-section-en">PROFILE</div>
        <div class="settings-section-jp">あなたについて</div>
      </div>
    </div>

    <div class="panel">
      <div class="field">
        <div class="field-label-row">
          <span class="label-en">HANDLE / ハンドル</span>
          <span class="label-hint">@で始まる半角英数</span>
        </div>
        <input class="input" type="text" id="settings-handle"
               value="${esc(profile.handle || '')}" placeholder="@your_name" maxlength="20">
      </div>

      <div class="field">
        <div class="field-label-row">
          <span class="label-en">DISPLAY NAME / 表示名</span>
        </div>
        <input class="input" type="text" id="settings-display-name"
               value="${esc(profile.display_name || '')}" placeholder="ニックネーム" maxlength="20">
      </div>

      <div class="field">
        <div class="field-label-row">
          <span class="label-en">SUBTITLE / サブタイトル</span>
          <span class="label-hint">15文字前後</span>
        </div>
        <input class="input" type="text" id="settings-subtitle"
               value="${esc(profile.subtitle || '')}" placeholder="例：映像制作で食べていく道" maxlength="30">
      </div>

      <div class="field">
        <div class="field-label-row">
          <span class="label-en">CAMPUS / 所属大学</span>
        </div>
        <input class="input" type="text" id="settings-campus"
               value="${esc(profile.campus || '')}" placeholder="○○大学" maxlength="50">
      </div>

      <div class="field">
        <div class="field-label-row">
          <span class="label-en">CURRENT YEAR / 現在の学年</span>
        </div>
        <select class="select" id="settings-current-year">
          <option value="daigaku_1" ${profile.current_year === 'daigaku_1' ? 'selected' : ''}>大学1年</option>
          <option value="daigaku_2" ${profile.current_year === 'daigaku_2' ? 'selected' : ''}>大学2年</option>
          <option value="daigaku_3" ${profile.current_year === 'daigaku_3' ? 'selected' : ''}>大学3年</option>
          <option value="daigaku_4" ${profile.current_year === 'daigaku_4' ? 'selected' : ''}>大学4年</option>
          <option value="shakaijin" ${profile.current_year === 'shakaijin' ? 'selected' : ''}>社会人（卒業生）</option>
        </select>
        <div class="settings-field-hint">計画ページの「いま」の位置を決めます</div>
      </div>
    </div>
  `;
}

/** 統計表示 */
function renderSettingsStats(cards, reflected) {
  return html`
    <div class="settings-section-head">
      <div class="settings-section-num">02</div>
      <div class="settings-section-title-block">
        <div class="settings-section-en">STATS</div>
        <div class="settings-section-jp">あなたの記録</div>
      </div>
    </div>

    <div class="settings-stats">
      <div class="settings-stat">
        <div class="settings-stat-num">${cards.length}</div>
        <div class="settings-stat-label">CARDS</div>
      </div>
      <div class="settings-stat">
        <div class="settings-stat-num">${reflected}</div>
        <div class="settings-stat-label">FURIKAERI</div>
      </div>
      <div class="settings-stat">
        <div class="settings-stat-num">${(Store.userPlan.liked_card_ids || []).length}</div>
        <div class="settings-stat-label">LIKED</div>
      </div>
    </div>
  `;
}

/** データ管理 */
function renderSettingsData() {
  const lastUpdated = Store.userPlan.updated_at;
  const lastUpdatedStr = lastUpdated ? new Date(lastUpdated).toLocaleString('ja-JP') : '—';

  return html`
    <div class="settings-section-head">
      <div class="settings-section-num">03</div>
      <div class="settings-section-title-block">
        <div class="settings-section-en">DATA</div>
        <div class="settings-section-jp">データの保管</div>
      </div>
    </div>

    <div class="panel">
      <div class="settings-data-row">
        <span class="settings-data-key">最終更新</span>
        <span class="settings-data-val">${esc(lastUpdatedStr)}</span>
      </div>
      <div class="settings-data-row">
        <span class="settings-data-key">保存場所</span>
        <span class="settings-data-val">この端末（localStorage）</span>
      </div>
      <div class="settings-data-row">
        <span class="settings-data-key">スキーマ版</span>
        <span class="settings-data-val">v${esc(Store.userPlan.schema_version || 1)}</span>
      </div>
      <div class="settings-data-note">
        データは <strong>この端末のブラウザにだけ</strong> 保存されています。<br>
        別の端末で続けたい時、ブラウザを変える時、書き溜めた内容を残したい時は、エクスポートしておくと安心です。
      </div>
    </div>

    <button class="settings-action-btn settings-action-export" onclick="handleExportData()">
      <span class="settings-action-icon">▼</span>
      <div class="settings-action-text">
        <div class="settings-action-title">JSON でエクスポート</div>
        <div class="settings-action-sub">計画ぜんぶをファイルとしてダウンロード</div>
      </div>
    </button>

    <button class="settings-action-btn settings-action-import" onclick="handleImportData()">
      <span class="settings-action-icon">▲</span>
      <div class="settings-action-text">
        <div class="settings-action-title">JSON でインポート</div>
        <div class="settings-action-sub">バックアップした計画を読み込む（現在のデータは上書き）</div>
      </div>
    </button>
    <input type="file" id="settings-import-file" accept=".json,application/json" hidden>

    <button class="settings-action-btn settings-action-danger" onclick="handleResetData()">
      <span class="settings-action-icon">✕</span>
      <div class="settings-action-text">
        <div class="settings-action-title">すべての計画をリセット</div>
        <div class="settings-action-sub">カードもプロフィールも全削除（取り消せません）</div>
      </div>
    </button>
  `;
}

/** アプリ情報 */
function renderSettingsAbout() {
  return html`
    <div class="settings-section-head">
      <div class="settings-section-num">04</div>
      <div class="settings-section-title-block">
        <div class="settings-section-en">ABOUT</div>
        <div class="settings-section-jp">このアプリについて</div>
      </div>
    </div>

    <div class="settings-about">
      <div class="settings-about-logo">ダイハック</div>
      <div class="settings-about-tagline">
        4年間の動き方を、<br>
        <span class="settings-about-emp">先輩</span>から学んで、<span class="settings-about-emp">後輩</span>に渡す
      </div>

      <div class="settings-about-meta">
        <div class="settings-about-meta-row">
          <span class="settings-about-meta-key">VERSION</span>
          <span class="settings-about-meta-val">${esc(APP_VERSION)}</span>
        </div>
        <div class="settings-about-meta-row">
          <span class="settings-about-meta-key">SCHEMA</span>
          <span class="settings-about-meta-val">v${esc(Store.userPlan.schema_version || 1)}</span>
        </div>
      </div>

      <div class="settings-about-body">
        ダイハックは、大学生の <strong>「進行中の道」</strong> を残して、後輩に渡すアプリです。<br><br>
        完成した道だけじゃなく、まだ通過中の道こそ、これから始める人の参考になります。<br>
        先輩のカードを <strong>自分の言葉でアレンジ</strong> しながら、<br>
        4年間の動き方を組み立てていってください。
      </div>
    </div>
  `;
}

/* ========== Settings event handlers ========== */

function attachSettingsEventHandlers() {
  ['handle', 'display-name', 'subtitle', 'campus'].forEach(field => {
    const el = document.getElementById(`settings-${field}`);
    if (el) {
      el.addEventListener('input', () => {
        ensureProfile();
        const key = field.replace(/-/g, '_');
        Store.userPlan.profile[key] = el.value;
        saveUserPlan();
      });
    }
  });

  const yearSelect = document.getElementById('settings-current-year');
  if (yearSelect) {
    yearSelect.addEventListener('change', () => {
      ensureProfile();
      Store.userPlan.profile.current_year = yearSelect.value;
      saveUserPlan();
      showToast('現在の学年を更新しました', 'success');
    });
  }

  const importFile = document.getElementById('settings-import-file');
  if (importFile) {
    importFile.addEventListener('change', handleImportFileSelected);
  }
}

window.handleExportData = function() {
  const json = JSON.stringify(Store.userPlan, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const date = new Date().toISOString().slice(0, 10);
  a.href = url;
  a.download = `daihack-plan-${date}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  showToast('JSON をダウンロードしました', 'success');
};

window.handleImportData = function() {
  const input = document.getElementById('settings-import-file');
  if (input) input.click();
};

async function handleImportFileSelected(event) {
  const file = event.target.files?.[0];
  if (!file) return;

  try {
    const text = await file.text();
    const parsed = JSON.parse(text);

    // 軽いバリデーション
    if (!parsed || typeof parsed !== 'object') {
      throw new Error('Not an object');
    }
    if (!Array.isArray(parsed.cards)) {
      throw new Error('Missing cards array');
    }

    // 確認
    const ok = confirm(
      `現在のデータを上書きします。\n\n` +
      `インポートするカード数: ${parsed.cards.length}\n\n` +
      `現在のデータは消えます。続けますか？`
    );
    if (!ok) {
      event.target.value = '';
      return;
    }

    Store.userPlan = {
      schema_version: parsed.schema_version || 1,
      created_at: parsed.created_at || new Date().toISOString(),
      updated_at: new Date().toISOString(),
      profile: parsed.profile || {},
      cards: parsed.cards || [],
      liked_card_ids: parsed.liked_card_ids || [],
      intentional_overlaps: parsed.intentional_overlaps || [],
    };
    saveUserPlan();
    showToast(`${parsed.cards.length} 枚のカードを読み込みました`, 'success');
    handleRouteChange();
  } catch (e) {
    console.error('Import failed:', e);
    showToast('読み込みに失敗しました（JSONの形式が違うかも）', 'warn');
  } finally {
    event.target.value = '';
  }
}

window.handleResetData = function() {
  // 二段階確認
  const cards = Store.userPlan.cards?.length || 0;
  const step1 = confirm(
    `本当にすべてのデータをリセットしますか？\n\n` +
    `削除されるもの:\n` +
    `・カード ${cards} 枚\n` +
    `・プロフィール\n` +
    `・いいね・重なり受け入れ記録\n\n` +
    `この操作は取り消せません。`
  );
  if (!step1) return;

  // 2段階目：「reset」と入力
  const step2 = prompt('確認のため "reset" と入力してください');
  if (step2 !== 'reset') {
    showToast('リセットを中止しました');
    return;
  }

  // 実行
  Store.userPlan = createEmptyPlan();
  saveUserPlan();
  showToast('すべてのデータをリセットしました', 'success');
  handleRouteChange();
};

/* ============================================================
   6. プレースホルダー用の最小スタイル
   （style.cssに置くべきか迷ったが、開発中のプレースホルダー専用なので
    JS側で動的注入して、画面完成後に削除する）
   ============================================================ */
(function injectPlaceholderStyles() {
  const css = `
    .placeholder-screen {
      background: var(--paper);
      border: 2px dashed var(--ink);
      padding: 16px;
      box-shadow: 3px 3px 0 var(--ink);
    }
    .placeholder-title {
      font-weight: 900;
      font-size: 16px;
      margin-bottom: 6px;
    }
    .placeholder-desc {
      font-size: 12px;
      line-height: 1.6;
      margin-bottom: 12px;
    }
    .placeholder-actions {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }
    .placeholder-model-row {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 8px 10px;
      background: var(--bg);
      border: 1.5px solid var(--ink);
      margin-bottom: 6px;
      text-decoration: none;
      color: inherit;
    }
  `;
  const style = document.createElement('style');
  style.id = 'placeholder-styles';
  style.textContent = css;
  document.head.appendChild(style);
})();

/* ============================================================
   7. グローバルイベントハンドラ
   ============================================================ */

/** リミックスへの動線（保存ボタンが押された時） */
window.handleSaveCard = function(modelId, cardId) {
  // すでに保存済みなら通知のみ
  if (isCardSaved(modelId, cardId)) {
    showToast('すでに計画に追加されています');
    return;
  }
  // リミックスシートへ
  navigateTo(`#/remix/${modelId}/${cardId}`);
};

/** いいねボタン */
window.handleLikeCard = function(modelId, cardId) {
  const key = `${modelId}:${cardId}`;
  if (!Store.userPlan.liked_card_ids) Store.userPlan.liked_card_ids = [];
  const idx = Store.userPlan.liked_card_ids.indexOf(key);
  const nowLiked = idx === -1;
  if (nowLiked) {
    Store.userPlan.liked_card_ids.push(key);
    showToast('いいねしました', 'success');
  } else {
    Store.userPlan.liked_card_ids.splice(idx, 1);
  }
  saveUserPlan();
  // アコーディオンの開閉状態を保つため、ボタンだけその場で更新
  const btns = document.querySelectorAll(`[data-like-btn="${CSS.escape(key)}"]`);
  if (btns.length > 0) {
    btns.forEach(btn => {
      btn.classList.toggle('model-like-btn-liked', nowLiked);
      btn.textContent = nowLiked ? '♥' : '♡';
      btn.setAttribute('aria-label', nowLiked ? 'いいねを取り消す' : 'いいね');
    });
  } else {
    handleRouteChange();
  }
};

/** コラボメッセージ送信（未実装：今は通知のみ） */
window.handleCollabMessage = function(modelId) {
  const model = getModel(modelId);
  showToast(`${model?.display_name || ''}さんへのメッセージ機能は近日公開`);
};

/** リミックスへの動線（旧呼び出し名・後方互換） */
window.quickSaveCard = function(modelId, cardId) {
  handleSaveCard(modelId, cardId);
};

/** モーダルを閉じる */
window.closeModal = function() {
  goBack();
};

/** クリックデリゲーション（data-action 属性で処理を分岐） */
document.addEventListener('click', (e) => {
  const target = e.target.closest('[data-action]');
  if (!target) return;
  const action = target.dataset.action;
  switch (action) {
    case 'back':
      goBack();
      break;
    case 'close-modal':
      closeModal();
      break;
    case 'open-settings':
      navigateTo('#/settings');
      break;
  }
});

/* ============================================================
   8. PWA Service Worker 登録
   ============================================================ */
function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) return;
  // 本番環境のみ登録（file:// で動かしている開発時は無視）
  if (location.protocol === 'file:') return;
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js').catch(err => {
      console.warn('Service Worker registration failed:', err);
    });
  });
}

/* ============================================================
   9. 起動
   ============================================================ */

async function bootstrap() {
  try {
    // データロード
    await loadStaticData();
    loadUserPlan();

    // ブラウザ通知（設定ONのユーザーのみ）: 起動時＋10分ごとにチェック
    runBrowserNotifications();
    setInterval(runBrowserNotifications, 10 * 60 * 1000);

    // ローディング画面を消す
    document.getElementById('loading').hidden = true;
    document.getElementById('app').hidden = false;

    // ハッシュ変更でルーティング
    window.addEventListener('hashchange', () => {
      if (__suppressNextRouteRender) { __suppressNextRouteRender = false; return; }
      handleRouteChange();
    });

    // 初回ルーティング
    handleRouteChange();

    // PWA Service Worker
    registerServiceWorker();
  } catch (e) {
    console.error('Bootstrap failed:', e);
    document.getElementById('loading').innerHTML = html`
      <div class="loading-content">
        <div class="loading-logo">ダイハック</div>
        <div style="color:var(--vermilion); font-size:14px; max-width:300px;">
          データの読み込みに失敗しました。<br>
          ページを再読み込みしてください。
        </div>
      </div>
    `;
  }
}

bootstrap();
